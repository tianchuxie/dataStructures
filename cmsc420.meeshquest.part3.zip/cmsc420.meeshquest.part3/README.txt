Readme: 
I used my previous Part2 as the most of the bascis, 
I used HashMap and treeMap (in Java) to implement some important areas in the Messhquest
I used https://drive.google.com/file/d/0B_o90-DTy7iHMTltRUtHck1yTEk/view?usp=sharing on the Piazza to get free points from SortedMap and something like it.
 