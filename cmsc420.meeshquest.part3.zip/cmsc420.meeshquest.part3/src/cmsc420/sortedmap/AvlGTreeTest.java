package cmsc420.sortedmap;
import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.junit.Test;

import cmsc420.meeshquest.part3.City;

public class AvlGTreeTest {

	@Test
	public void testEntrySet(){
		AvlGTree<String, Integer> t1=new AvlGTree<String, Integer>(String.CASE_INSENSITIVE_ORDER, 1);
		SortedMap<String, Integer> s1=new TreeMap<String, Integer>();
		t1.put("a", 1);
		t1.put("b", 2);
		t1.put("c", 3);
		t1.put("d", 4);
		t1.put("e", 5);
		Set<java.util.Map.Entry<String, Integer>> e1=t1.entrySet();
		Iterator<java.util.Map.Entry<String, Integer>> i1=t1.entrySet().iterator();
		while(i1.hasNext()){
			java.util.Map.Entry<String, Integer> e=i1.next();
			assertTrue(t1.containsKey(e.getKey()));
			assertTrue(t1.containsValue(e.getValue()));
			s1.put(e.getKey(), e.getValue());
			assertTrue(t1.get(e.getKey()).equals(s1.get(e.getKey())));
		}
		Set<java.util.Map.Entry<String, Integer>> e2=s1.entrySet();
		assertTrue(t1.equals(s1));
		assertTrue(t1.entrySet().equals(s1.entrySet()));
		assertTrue(e1.equals(e2));
		assertTrue(e1.hashCode()==e2.hashCode());
		t1.put("f", 6);
		assertFalse(t1.equals(s1));
		assertFalse(e1.equals(e2));
		assertFalse(t1.entrySet().equals(s1.entrySet()));
		assertFalse(e1.hashCode()==e2.hashCode());
		s1.put("f", 6);
		assertTrue(t1.equals(s1));
		assertTrue(e1.equals(e2));
		assertTrue(t1.entrySet().equals(s1.entrySet()));
		assertTrue(e1.hashCode()==e2.hashCode());
	}
	
	@Test
	public void testHashCode() {
		AvlGTree<String, City> avl = new AvlGTree<String, City>(String.CASE_INSENSITIVE_ORDER,2);
		TreeMap<String, City> tm = new TreeMap<String, City>();

	
		
		avl.putAll(tm);
		
		assertEquals(tm.hashCode(), avl.hashCode());
	}

}
