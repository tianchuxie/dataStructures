package cmsc420.meeshquest.part3;

import java.awt.Color;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;



public class City extends Point2D.Float {
    private String name;
    private String color;
    private int r;
    protected String type;
    protected int rx, ry;
   public City (){
	   setName("not");
   }
   
   public String toString(){
	   String returnt = "(" +  (int)super.x + "," + (int) super.y + ")";
	return returnt;
	   
   }
    
    public City (String cName, String cColor,int rx, int ry, int lx, int ly,  int r){
    	super.x = lx;
    	super.y = ly;
    	this.r = r;
    	this.rx = rx;
    	this.ry = ry;
    	setName(cName);
    	setColor(cColor);
    	this.type = "city";
    }
    
    public int getRx(){
    	return this.rx;
    }
    
    public int getRy(){
    	return this.ry;
    }
    
    public int getLx(){
    	return (int) getX();
 
    }

    public int getLy(){
    	return (int) getY();
    }
    
    public String getType(){
    	return this.type;
    }
    
    public void setType(String type){
    	this.type = type;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}
	
	public int getR(){
		return this.r;
	}

	public void setColor(String color) {
		this.color = color;
	}


	public Point2D.Float toPoint2D() {
		// TODO Auto-generated method stub
		return new Point2D.Float(super.x, super.y);
	}
   
	
	
    


}






