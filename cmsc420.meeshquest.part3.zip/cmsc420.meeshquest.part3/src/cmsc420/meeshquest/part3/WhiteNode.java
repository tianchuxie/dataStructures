package cmsc420.meeshquest.part3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import cmsc420.drawing.CanvasPlus;

public class WhiteNode extends PRNode {
 
	public WhiteNode(double x1, double x2, double y1, double y2){
		super.setX1(x1);
		super.setY1(y1);
		super.setX2(x2);
		super.setY2(y2);
	}
	public PRNode insert(City city) {
	
		return new Blacknode(city, super.getX1(), super.getX2(), super.getY1(), super.getY2());
	}
	
	
	
	@Override
	public PRNode delete(City city) {
		// TODO Auto-generated method stub
		return this;
	}
	@Override
	public void print(Document results, PRNode t, Element parent) {
		Element whitenode = results.createElement("white");
		parent.appendChild(whitenode);
		
	}
	@Override
	public void canvansPrint(CanvasPlus c) {
		// TODO Auto-generated method stub
		
	}
	/*
	@Override
	public ArrayList<City> rangeCities(double x, double y, double r) {
		// TODO Auto-generated method stub
		return new ArrayList<City> ();
	}
	*/
	@Override
	public TreeSet<City> rangeCities(double x, double y, double r, Comparator<City> cityComp) {
		// TODO Auto-generated method stub
		return new TreeSet<City>();
	}
	@Override
	public PRNode insertR(Road r) {
		if (cross (r)){
			  return new Blacknode( r, super.getX1(), super.getX2(), super.getY1(), super.getY2());
		}
		return this;
		
	}

}
