package cmsc420.meeshquest.part3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.awt.Color;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import cmsc420.geom.Inclusive2DIntersectionVerifier;
import cmsc420.meeshquest.part3.City;
import cmsc420.meeshquest.part3.PMQuadtree.PMEcpt;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import cmsc420.xml.XmlUtility;
import cmsc420.drawing.CanvasPlus;
import cmsc420.sortedmap.AvlGTree;
import cmsc420.sortedmap.GuardedAvlGTree;

public class MeeshQuest {
	private static int localwidth;
	private static int localheight;
	private static int remotewidth;
	private static int remoteheight;
	private static int g_value;
	private static int pmOrder;
	private static CanvasPlus canvas;
    private static TreeMap<String, City> nameFindCity = new TreeMap<String, City> (stringCompare());
    private static TreeSet<City>  cordFindCity = new TreeSet<City> (cordCom());
    private static TreeSet<Road> roads = new TreeSet<Road>(roadComp());
    private static TreeMap<String, City> cityMap = new TreeMap<String, City>();
    private static HashMap<Point2D.Float, ArrayList<City>> onlycity; 
    private static TreeMap<String, Airport> airports = new TreeMap<String, Airport>();
    private static TreeMap<String, Term> terms = new TreeMap<String, Term>();
    private static TreeMap<String, City> allCity = new TreeMap<String, City>();
    private static TreeSet<String> mapped = new TreeSet<String>();
    private static AVLTree avl = new AVLTree();
    private static GuardedAvlGTree<String, City> avlg;
    private static TreeMap<String, ArrayList<String>> roadmap = new TreeMap<String, ArrayList<String>>(stringCompareRight());
    
    private static HashMap<Point2D.Float, PMQuadtree> remote = new HashMap<Point2D.Float, PMQuadtree> ();
    
    
    
    public static boolean PMtryR(Road r, PMQuadtree spatialMap){
    	boolean returnt = true;
    	try {
    		spatialMap.insertR(r);
    	} catch (PMEcpt e1){
    		returnt = false;
    		spatialMap.deleteR(r);
    	}
    	
    	return returnt;
    }
    
    public static boolean PMtryC(City c, PMQuadtree spatialMap){
    	boolean returnt = true;
    	try {
    		spatialMap.insertC(c);
    	} catch (PMEcpt e1){
    		returnt = false;
    	}
    	
    	return returnt;
    }
     
    public static Comparator<Road> roadComp(){
		return new Comparator<Road>(){


			@Override
			public int compare(Road o1, Road o2) {
				if (o1.getSc().getName().compareTo(o2.getSc().getName()) != 0){
					if (o1.getSc().getName().compareTo(o2.getSc().getName()) >0){
						return -1;
					} else {
						return 1;
					}
				} else {
					if (o1.getEc().getName().compareTo(o2.getEc().getName()) >0){
						return -1;
					} else if (o1.getEc().getName().compareTo(o2.getEc().getName()) <0){
						return 1;
					} else {
						return 0;
					}
				}
			}

		};
	}
    
    public static Comparator<City> cityComp(){
		return new Comparator<City>(){


			@Override
			public int compare(City o1, City o2) {
				if (o1.getName().compareTo(o2.getName()) < 0){
					return 1;
				} else if (o1.getName().compareTo(o2.getName()) > 0){
					return -1;
				} else {
					return 0;
				}
			}

		};
	}
    
   
    public static Comparator<String> stringCompareRight(){
		return new Comparator<String>(){

			@Override
			public int compare(String city1, String city2) {

				if (city1.compareTo(city2) < 0){
					return -1;
				} else if (city1.compareTo(city2) > 0){
					return 1;
				} else {
					return 0;
				}
			}

		};
	}
    
    
    public static Comparator<String> stringCompare(){
		return new Comparator<String>(){

			@Override
			public int compare(String city1, String city2) {

				if (city1.compareTo(city2) < 0){
					return 1;
				} else if (city1.compareTo(city2) > 0){
					return -1;
				} else {
					return 0;
				}
			}

		};
	}
    
	public static Comparator<City> cordCom(){
		return new Comparator<City>(){

			@Override
			public int compare(City city1, City city2) {
				int rx1 = city1.getRx();
				int lx1 = city1.getLx();
				int ry1 = city1.getRy();
				int ly1 = city1.getLy();
				
				int rx2 = city2.getRx();
				int lx2 = city2.getLx();
				int ry2 = city2.getRy();
				int ly2 = city2.getLy();
				
				if (rx1 == rx2 && ry1 == ry2){

					if(ly1 != ly2){
						return ly1 > ly2?  1 : -1;
					}else if(lx1 != lx2){
						return lx1 > lx2? 1 : -1;
					}else {
						return 0;
					}
				} else {
					if(ry1 != ry2){
						return ry1 > ry2?  1 : -1;
					}else if(rx1 != rx2){
						return rx1 > rx2? 1 : -1;
					}else {
						return 0;
					}
					
				}
			}

		};
	}
	
	public static Comparator<City> cityNameComparator(){
		return new Comparator<City>(){

			@Override
			public int compare(City city1, City city2) {
				int result = city1.getName().compareTo(city2.getName());
				if(result < 0)
					return -1;
				else if(result > 0)
					return 1;
				else//equal
					return 0;
			}

		};
	}
	

    public static void main(String[] args) {
    	
    	Document results = null;
    	FileInputStream xmlFile = null;
		try {
			xmlFile = new FileInputStream("part2.public.avlg.input.xml");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
    	

    	
        try {
        	Document doc = XmlUtility.validateNoNamespace(System.in);
        	results = XmlUtility.getDocumentBuilder().newDocument();
        	Element root = results.createElement("results");
        	results.appendChild(root);
        	
        	
        
        	Element commandNode = doc.getDocumentElement();
        	Element docRoot = doc.getDocumentElement();
        	
        	
        	Node rootNode = docRoot.getFirstChild().getParentNode();	
    		NamedNodeMap commandAttr = rootNode.getAttributes();
    		
    		localwidth = Integer.parseInt(commandAttr.getNamedItem("localSpatialWidth").getNodeValue());
    		localheight = Integer.parseInt(commandAttr.getNamedItem("localSpatialHeight").getNodeValue());

    		remotewidth = Integer.parseInt(commandAttr.getNamedItem("remoteSpatialWidth").getNodeValue());
    		remoteheight = Integer.parseInt(commandAttr.getNamedItem("remoteSpatialHeight").getNodeValue());
    		
    		g_value = Integer.parseInt(commandAttr.getNamedItem("g").getNodeValue());
    		
    		pmOrder = 3;
    		
    		try {
    			pmOrder = Integer.parseInt(commandAttr.getNamedItem("pmOrder").getNodeValue());
				} catch (NullPointerException e1) {
					// TODO Auto-generated catch block
					
				} 
	
            avlg = new  GuardedAvlGTree<String, City>(stringCompare(), g_value);
 
        
            nameFindCity = new TreeMap<String, City> (stringCompare());
            cordFindCity = new TreeSet<City> (cordCom());
             roads = new TreeSet<Road>(roadComp());
            cityMap = new TreeMap<String, City>();
            terms = new TreeMap<String, Term>();
            allCity = new TreeMap<String, City>();
            avl = new AVLTree ();
            onlycity = new HashMap<Point2D.Float, ArrayList<City>>();
           
            roadmap = new TreeMap<String, ArrayList<String>>(stringCompareRight());
            mapped = new TreeSet<String>();
            
    		
    		canvas = new CanvasPlus("MeeshQuest", localwidth, localheight);
    		canvas.addRectangle(0, 0, localwidth, localheight, Color.BLACK, false);
    		
    		remote = new HashMap<Point2D.Float, PMQuadtree> ();
    		
    		
    		
        	final NodeList nl = commandNode.getChildNodes();
        	for (int i = 0; i < nl.getLength(); i++) {
        		if (nl.item(i).getNodeType() == Document.ELEMENT_NODE) {
        			commandNode = (Element) nl.item(i);
                   Node commandIn = nl.item(i);
                   commandAttr = commandIn.getAttributes();
                   if (commandIn.getNodeName().equals("createCity")){
                	   
                	   String name = commandAttr.getNamedItem("name").getNodeValue();
       					int clx = Integer.parseInt(commandAttr.getNamedItem("localX").getNodeValue());
       					int cly = Integer.parseInt(commandAttr.getNamedItem("localY").getNodeValue());
       					int crx = Integer.parseInt(commandAttr.getNamedItem("remoteX").getNodeValue());
       					int cry = Integer.parseInt(commandAttr.getNamedItem("remoteY").getNodeValue());
       					int cr = Integer.parseInt(commandAttr.getNamedItem("radius").getNodeValue());
       					Element command = results.createElement("command");
       					command.setAttribute("name", "createCity");
       					
       					
       					String id = "";
       					try {
       						id = commandAttr.getNamedItem("id").getNodeValue();
       						command.setAttribute("id", id);
       					} catch (NullPointerException e1) {
       						// TODO Auto-generated catch block
       						
       					} 
       		
       				    String ccolor = commandAttr.getNamedItem("color").getNodeValue();
       				    City newCity = new City(name, ccolor, crx, cry,clx, cly, cr);
       				    boolean samecord = false;
       				    boolean overloop = false;
       				    
       				    
       				 Element parameters = results.createElement("parameters");
						Element pname = results.createElement("name");
						Element elx = results.createElement("localX");
						Element ely = results.createElement("localY");
						Element erx = results.createElement("remoteX");
						Element ery = results.createElement("remoteY");
						Element radius = results.createElement("radius");
						Element color = results.createElement("color");
						
						
						
						pname.setAttribute("value", newCity.getName());
						elx.setAttribute("value", String.valueOf((int) newCity.getLx()));
						ely.setAttribute("value", String.valueOf((int) newCity.getLy()));
						erx.setAttribute("value", String.valueOf((int) newCity.getRx()));
						ery.setAttribute("value", String.valueOf((int) newCity.getRy()));
						radius.setAttribute("value", String.valueOf(newCity.getR()));
						color.setAttribute("value", String.valueOf(newCity.getColor()));
						parameters.appendChild(pname);
						parameters.appendChild(elx);
						parameters.appendChild(ely);
						parameters.appendChild(erx);
						parameters.appendChild(ery);
						parameters.appendChild(radius);
						parameters.appendChild(color);
       				    
       				    
       				    
       				    
       				    
       				 for (City c: cordFindCity){
							if (c.getX() == newCity.getX() && c.getY() == newCity.getY() && c.getRx() == newCity.getRx() && c.getRy() == newCity.getRy()) {
								samecord = true;
							}
							
						}
       				/* for (City c: cordFindCity){
       					 /*Math.sqrt((c.getX() - newCity.getX())*(c.getX() - newCity.getX())
       							            + (c.getY() - newCity.getY())* (c.getY() - newCity.getY()))
       					 double distance = Point2D.distance(c.getX(), c.getY(), newCity.getX(), newCity.getY());
       					 double rd = c.getR() + newCity.getR();
							if (distance < c.getR() || distance < newCity.getR()){
								overloop = false;
							}
							
						}
                   
    				 */
       				    
       				    
       				    
       				    if (samecord){

       						Element error = results.createElement("error");
       						error.setAttribute("type", "duplicateCityCoordinates");
       						root.appendChild(error);
       						error.appendChild(command);
       						error.appendChild(parameters);			    	
       				    } else{  	
       				      if (nameFindCity.containsKey(name) ){

         						Element error = results.createElement("error");	
         						error.setAttribute("type", "duplicateCityName");
         						root.appendChild(error);
         						error.appendChild(command);
         						error.appendChild(parameters);
  
       				   	    	  
       				    	  
       				      } else if (overloop ){
       				    	Element error = results.createElement("error");
     						error.setAttribute("type", "cityInRangeOfOtherCity");
     						command.setAttribute("name", "createCity");
     						root.appendChild(error);
     						error.appendChild(command);
     						error.appendChild(parameters);
       				      } else { 
       				    	nameFindCity.put(name, newCity);
       				    	cordFindCity.add(newCity);
       				    	allCity.put(name, nameFindCity.get(name));
               			    avl.insert(name);
               			    avlg.put(name,nameFindCity.get(name));
               			    /*avlg.insert(name, newCity);*/
       				    	 
       				    	XMLout.outsucces(results, newCity, root,id, parameters); 
       				      }
       				  
       				    	
       				    }
       				
       				
                   } else if (commandIn.getNodeName().equals("deleteCity")) {
                	   String name = commandAttr.getNamedItem("name").getNodeValue();
                	   Element pname = results.createElement("name");
                	   pname.setAttribute("value", name);
                	   if (nameFindCity.containsKey(name)){
                		   cordFindCity.remove(nameFindCity.get(name));
                		   nameFindCity.remove(name);
                		  
                		   
                		   
                		   Element success = results.createElement("success");
   							Element command = results.createElement("command");
   							Element parameters = results.createElement("parameters");
   							
   							Element output = results.createElement("output");

   							command.setAttribute("name", "deleteCity");
   							

   							root.appendChild(success);
   							success.appendChild(command);
   							success.appendChild(parameters);
   							parameters.appendChild(pname);
   							success.appendChild(output);	
   							if (airports.containsKey(name)){
   							/*	City c = airports.get(name);
   								Element cityE = results.createElement("cityUnmapped");
   	        					cityE.setAttribute("name", name);
   	        					cityE.setAttribute("x", String.valueOf((int)c.getX()));
   	        					cityE.setAttribute("y", String.valueOf((int)c.getY()));
   	        					cityE.setAttribute("color", c.getColor());
   	        					cityE.setAttribute("radius", String.valueOf((int)c.getR()));
   	        					
   	        					output.appendChild(cityE);
   	            				airports.remove(name);*/
   							}
   							
   							
   							
                	   } else {
                		   Element error = results.createElement("error");
   							Element parameters = results.createElement("parameters");
   							Element command = results.createElement("command");

   							error.setAttribute("type", "cityDoesNotExist");
   							command.setAttribute("name", "deleteCity");

   							root.appendChild(error);
   							error.appendChild(command);
   							error.appendChild(parameters);
   							parameters.appendChild(pname);
                		   
                		   
                	   }

                	   
           			
           		} else if (commandIn.getNodeName().equals("clearAll")) {
           			
           			Element command = results.createElement("command");
    				command.setAttribute("name", "clearAll");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			
           		  nameFindCity = new TreeMap<String, City> (stringCompare());
           	      cordFindCity = new TreeSet<City> (cordCom());
           		  avl.makeEmpty();
           		  airports = new TreeMap<String, Airport>();
           		  roadmap = new TreeMap<String, ArrayList<String>>();
           		  cityMap = new TreeMap<String, City>();
           	
           		onlycity = new HashMap<Point2D.Float, ArrayList<City>>();
           			
           			
           			Element success = results.createElement("success");
					Element parameters = results.createElement("parameters");
					Element output = results.createElement("output");

	

					root.appendChild(success);
					success.appendChild(command);
					success.appendChild(parameters);
					success.appendChild(output);

           			
           			
          
           			
           		} else if (commandIn.getNodeName().equals("listCities")) {
           			String listType  =commandAttr.getNamedItem("sortBy").getNodeValue();
           			Element parameters = results.createElement("parameters");
					Element sortBy = results.createElement("sortBy");
					sortBy.setAttribute("value", listType);
					parameters.appendChild(sortBy);
           			if (nameFindCity.size() == 0){
           				Element error = results.createElement("error");
					
						Element command = results.createElement("command");
						error.setAttribute("type", "noCitiesToList");
						command.setAttribute("name", "listCities");
						try {
       						String id = commandAttr.getNamedItem("id").getNodeValue();
       						command.setAttribute("id", id);
       					} catch (NullPointerException e1) {
       					
       						
       					} 

						root.appendChild(error);
						error.appendChild(command);
						error.appendChild(parameters);
						
           			} else {
           				Element success = results.createElement("success");
						Element command = results.createElement("command");
						
						Element output = results.createElement("output");
						Element cityList = results.createElement("cityList");
						Element cityE = results.createElement("city");
						
						command.setAttribute("name", "listCities");
						try {
       						String id = commandAttr.getNamedItem("id").getNodeValue();
       						command.setAttribute("id", id);
       					} catch (NullPointerException e1) {
       					
       						
       					} 

						
				
						if (listType.equals("name")){
							
							
							for (String key: nameFindCity.keySet()){
								City c = nameFindCity.get(key);
								cityE.setAttribute("name", c.getName());
								cityE.setAttribute("localX", String.valueOf((int) c.getLx()));
								cityE.setAttribute("localY", String.valueOf((int) c.getLy()));
								cityE.setAttribute("remoteX", String.valueOf((int) c.getRx()));
								cityE.setAttribute("remoteY", String.valueOf((int) c.getRy()));
								cityE.setAttribute("radius", String.valueOf(c.getR()));
								cityE.setAttribute("color", c.getColor());

								cityList.appendChild(cityE);
								cityE = results.createElement("city");
								
							}
						} else {
							for (City c:cordFindCity){
								cityE.setAttribute("name", c.getName());
								cityE.setAttribute("localX", String.valueOf((int) c.getLx()));
								cityE.setAttribute("localY", String.valueOf((int) c.getLy()));
								cityE.setAttribute("remoteX", String.valueOf((int) c.getRx()));
								cityE.setAttribute("remoteY", String.valueOf((int) c.getRy()));
								cityE.setAttribute("radius", String.valueOf(c.getR()));
								cityE.setAttribute("color", c.getColor());

								cityList.appendChild(cityE);
								cityE = results.createElement("city");
							}
							
							
						}
						
						

						root.appendChild(success);
						success.appendChild(command);
						success.appendChild(parameters);
						success.appendChild(output);
						output.appendChild(cityList);
           			}
           			
           		} else if (commandIn.getNodeName().equals("mapAirport")) {
           			String airportName = commandAttr.getNamedItem("name").getNodeValue();
           			String termName = commandAttr.getNamedItem("terminalName").getNodeValue();
           			String termCity = commandAttr.getNamedItem("terminalCity").getNodeValue();
           			int alx = Integer.parseInt(commandAttr.getNamedItem("localX").getNodeValue());
   					int aly = Integer.parseInt(commandAttr.getNamedItem("localY").getNodeValue());
   					int arx = Integer.parseInt(commandAttr.getNamedItem("remoteX").getNodeValue());
   					int ary = Integer.parseInt(commandAttr.getNamedItem("remoteY").getNodeValue());
   					int tx = Integer.parseInt(commandAttr.getNamedItem("terminalX").getNodeValue());
   				    int ty = Integer.parseInt(commandAttr.getNamedItem("terminalY").getNodeValue());
           		
             	   
             	   Element command = results.createElement("command");
  					command.setAttribute("name", "mapAirport");
  					String id = "";
  					try {
  						id = commandAttr.getNamedItem("id").getNodeValue();
  						command.setAttribute("id", id);
  					} catch (NullPointerException e1) {
  						// TODO Auto-generated catch block
  						
  					} 
  					Element parameters = results.createElement("parameters");
					Element pname = results.createElement("name");
					pname.setAttribute("value", airportName);
					Element elx = results.createElement("localX");
					Element ely = results.createElement("localY");
					Element erx = results.createElement("remoteX");
					Element ery = results.createElement("remoteY");
					elx.setAttribute("value", String.valueOf((int) alx));
					ely.setAttribute("value", String.valueOf((int) aly));
					erx.setAttribute("value", String.valueOf((int) arx));
					ery.setAttribute("value", String.valueOf((int) ary));
					Element tname = results.createElement("terminalName");
					tname.setAttribute("value", termName);
					
					Element etx = results.createElement("terminalX");
					Element ety = results.createElement("terminalY");
					etx.setAttribute("value", String.valueOf((int) tx));
					ety.setAttribute("value", String.valueOf((int) ty));
					
					Element cname = results.createElement("terminalCity");
					cname.setAttribute("value", termCity);

					
					parameters.appendChild(pname);
					parameters.appendChild(elx);
					parameters.appendChild(ely);
					parameters.appendChild(erx);
					parameters.appendChild(ery);
					parameters.appendChild(tname);
					parameters.appendChild(etx);
					parameters.appendChild(ety);
					parameters.appendChild(cname);
  					Airport newairport = new Airport(airportName, termName, termCity, alx, aly, arx, ary);
  					Term newterm = new Term(airportName, termName, termCity, tx, ty, arx, ary);
  					boolean samecordA = false;
  					boolean samecordT = false;
  					boolean airportViol = false;
  					for (Airport a: airports.values()){
						if (a.getLx() == newairport.getLx() && a.getLy() == newairport.getLy() && a.getRx() == newairport.getRx() && a.getRy() == newairport.getRy()){
							samecordA = true;
						}
						if (a.getLx() == newterm.getLx() && a.getLy() == newterm.getLy() && a.getRx() == newterm.getRx() && a.getRy() == newterm.getRy()){
							samecordT = true;
						}
					}
					for (City a: nameFindCity.values()){
						if (a.getLx() == newairport.getLx() && a.getLy() == newairport.getLy() && a.getRx() == newairport.getRx() && a.getRy() == newairport.getRy()){
							samecordA = true;
						}
						if (a.getLx() == newterm.getLx() && a.getLy() == newterm.getLy() && a.getRx() == newterm.getRx() && a.getRy() == newterm.getRy()){
							samecordT = true;
						}
					}
					
					for (Term a: terms.values()){
						if (a.getLx() == newairport.getLx() && a.getLy() == newairport.getLy() && a.getRx() == newairport.getRx() && a.getRy() == newairport.getRy()){
							samecordA = true;
						}
						if (a.getLx() == newterm.getLx() && a.getLy() == newterm.getLy() && a.getRx() == newterm.getRx() && a.getRy() == newterm.getRy()){
							samecordT = true;
						}
					}
					
				   for (Road r: roads){
					   if (r.contains(alx, aly) && r.getEc().getRx() == arx && r.getEc().getRx() == ary){
						   airportViol = true;
					   }
				   }
				   
				   PMQuadtree localMap = new PMQuadtree(localwidth, localheight, pmOrder); 
				   Point2D.Float rPoint = new Point2D.Float(arx, ary);
				   if (remote.containsKey(new Point2D.Float(arx, ary))){
					   localMap = remote.get(rPoint);
				   }
           			
           			if (airports.containsKey(airportName) || nameFindCity.containsKey(airportName) || terms.containsKey(airportName)){
           				XMLout.generror(results, root,"duplicateAirportName","mapAirport",parameters, command);
           			} else if (samecordA){
           				XMLout.generror(results, root,"duplicateAirportCoordinates","mapAirport",parameters, command);
           			} else if (alx > localwidth || aly > localheight || alx < 0 || aly < 0 
           					|| arx > remotewidth || ary > remoteheight || arx < 0 || ary < 0){
          				XMLout.generror(results, root,"airportOutOfBounds","mapAirport",parameters, command);
           			} else if (airports.containsKey(termName) || nameFindCity.containsKey(termName) || terms.containsKey(termName)){
           				XMLout.generror(results, root,"duplicateTerminalName","mapAirport",parameters, command);
           			} else if (samecordT){
           				XMLout.generror(results, root,"duplicateTerminalCoordinates","mapAirport",parameters, command);	
           			} else if (tx > localwidth || ty > localheight || tx < 0 || ty < 0 ){
          				XMLout.generror(results, root,"terminalOoutOfBounds","mapAirport",parameters, command);
           			} else if (!nameFindCity.containsKey(termCity)){
           				XMLout.generror(results, root,"connectingCityDoesNotExist","mapAirport",parameters, command);
           			} else if (!(arx == nameFindCity.get(termCity).getRx() && ary == nameFindCity.get(termCity).getRy() )){
           				XMLout.generror(results, root,"connectingCityNotInSameMetropole","mapAirport",parameters, command);
           			} else if (!PMtryC(newairport, localMap) || airportViol){
           				localMap.deleteC(newairport);
           				XMLout.generror(results, root,"airportViolatesPMRules","mapAirport",parameters, command);
           			} else if  (!cityMap.containsKey(termCity) ){
           				XMLout.generror(results, root,"connectingCityNotMapped","mapAirport",parameters, command);
           			} else if (PMtryR(new Road (newterm, nameFindCity.get(termCity)), localMap) == false){
           				localMap.deleteC(newairport);
           				XMLout.generror(results, root,"terminalViolatesPMRules","mapAirport",parameters, command);
           			} else {
           
           				Road newroad = new Road (newterm, nameFindCity.get(termCity)); 
           				boolean interset = false;
           				for (Road r: roads){
           					if (r.getEc().getRx() == newroad.getEc().getRx() && r.getEc().getRy() == newroad.getEc().getRy()){
           					if (r.getEc().getName().equals (newroad.getSc().getName())){
           						double rxx = r.getSc().getLx();
           						double rxy = r.getSc().getLy();
           						double nx = newroad.getEc().getLx();
           						double ny = newroad.getEc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           						
           					} else if (r.getEc().getName().equals(newroad.getEc().getName())){
           						double rxx = r.getSc().getLx();
           						double rxy = r.getSc().getLy();
           						double nx = newroad.getSc().getLx();
           						double ny = newroad.getSc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           					
           					}else if (r.getSc().getName().equals (newroad.getSc().getName())){
           						double rxx = r.getEc().getLx();
           						double rxy = r.getEc().getLy();
           						double nx = newroad.getEc().getLx();
           						double ny = newroad.getEc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           					} else  if ( r.getSc().getName().equals(newroad.getEc().getName())){
           						double rxx = r.getEc().getLx();
           						double rxy = r.getEc().getLy();
           						double nx = newroad.getSc().getLx();
           						double ny = newroad.getSc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           						
           					}else if (r.getLine().intersectsLine(newroad.getLine()) ){
           						interset = true;
           					}
           					}
           				
           				}
           				if (interset){
           					XMLout.generror(results, root,"roadIntersectsAnotherRoad","mapAirport",parameters, command);
           				} else {
           				
           					
           					try{
           					  localMap.insert(newairport);	
           					  localMap.insert(newroad);
           					  remote.put(rPoint, localMap);
           					}
           					catch (PMEcpt e1){
           					}
           				newairport.setType("airport");
           				newterm.setType("terminal");
           				airports.put(airportName, newairport);
           				terms.put(termName, newterm);
           				cityMap.put(airportName, newairport);
           				cityMap.put(termName, newterm);
           				cityMap.put(termName, nameFindCity.get(termCity));
        
           				cityMap.put(airportName, newairport);
         
           			    
           			 if (roadmap.containsKey(termName)){
            				roadmap.get(termName).add(termCity);		
            			} else {
            				ArrayList<String> k = new ArrayList<String> ();
            				k.add(termCity);
            				roadmap.put(termName, k);
            			}
            			
            			if (roadmap.containsKey(termCity)){
            				roadmap.get(termCity).add(termName);	
            			} else {
            				ArrayList<String> k = new ArrayList<String> ();
            				k.add(termName);
            				roadmap.put(termCity, k);
            			}
           			    
           			    
           			    
           			    Element success = results.createElement("success");
						Element output = results.createElement("output");
						root.appendChild(success);
						success.appendChild(command);
						success.appendChild(parameters);
					
						success.appendChild(output);
           			    
           			}
           			
           			}
           			
          		} else if (commandIn.getNodeName().equals("mapTerminal")) {
           			String airportName = commandAttr.getNamedItem("airportName").getNodeValue();
           			String termName = commandAttr.getNamedItem("name").getNodeValue();
           			String termCity = commandAttr.getNamedItem("cityName").getNodeValue();
           			int lx = Integer.parseInt(commandAttr.getNamedItem("localX").getNodeValue());
   					int ly = Integer.parseInt(commandAttr.getNamedItem("localY").getNodeValue());
   					int rx = Integer.parseInt(commandAttr.getNamedItem("remoteX").getNodeValue());
   					int ry = Integer.parseInt(commandAttr.getNamedItem("remoteY").getNodeValue());
   
           		
             	   
             	   Element command = results.createElement("command");
  					command.setAttribute("name", "mapTerminal");
  					String id = "";
  					try {
  						id = commandAttr.getNamedItem("id").getNodeValue();
  						command.setAttribute("id", id);
  					} catch (NullPointerException e1) {
  						// TODO Auto-generated catch block
  						
  					} 
  					Element parameters = results.createElement("parameters");
					Element pname = results.createElement("airportName");
					pname.setAttribute("value", airportName);
					Element elx = results.createElement("localX");
					Element ely = results.createElement("localY");
					Element erx = results.createElement("remoteX");
					Element ery = results.createElement("remoteY");
					elx.setAttribute("value", String.valueOf((int) lx));
					ely.setAttribute("value", String.valueOf((int) ly));
					erx.setAttribute("value", String.valueOf((int) rx));
					ery.setAttribute("value", String.valueOf((int) ry));
					Element tname = results.createElement("name");
					tname.setAttribute("value", termName);
					
					
					Element cname = results.createElement("cityName");
					cname.setAttribute("value", termCity);

					
					parameters.appendChild(tname);
					parameters.appendChild(elx);
					parameters.appendChild(ely);
					parameters.appendChild(erx);
					parameters.appendChild(ery);
					parameters.appendChild(cname);
					parameters.appendChild(pname);
  					Term newterm = new Term(airportName, termName, termCity, lx, ly, rx, ry);
  	
  					boolean samecordT = false;
  					boolean airportViol = false;
  					for (Airport a: airports.values()){
					
						if (a.getLx() == newterm.getLx() && a.getLy() == newterm.getLy() && a.getRx() == newterm.getRx() && a.getRy() == newterm.getRy()){
							samecordT = true;
						}
					}
					for (City a: nameFindCity.values()){
					
						if (a.getLx() == newterm.getLx() && a.getLy() == newterm.getLy() && a.getRx() == newterm.getRx() && a.getRy() == newterm.getRy()){
							samecordT = true;
						}
					}
					
					for (Term a: terms.values()){
				
						if (a.getLx() == newterm.getLx() && a.getLy() == newterm.getLy() && a.getRx() == newterm.getRx() && a.getRy() == newterm.getRy()){
							samecordT = true;
						}
					}
					
				   for (Road r: roads){
					   if ( r.getEc().getRx() == rx && r.getEc().getRx() == ry && r.contains(lx, ly) ){
						   airportViol = true;
					   }
				   }
				   
				   PMQuadtree localMap = new PMQuadtree(localwidth, localheight, pmOrder); 
				   Point2D.Float rPoint = new Point2D.Float(rx, ry);
				   if (remote.containsKey(new Point2D.Float(rx, ry))){
					   localMap = remote.get(rPoint);
				   }
           			
				   if (airports.containsKey(termName) || nameFindCity.containsKey(termName) || terms.containsKey(termName)){
          				XMLout.generror(results, root,"duplicateTerminalName","mapTerminal",parameters, command);
          			} else if (samecordT){
          				XMLout.generror(results, root,"duplicateTerminalCoordinates","mapTerminal",parameters, command);
           			} else if (lx > localwidth || ly > localheight || lx < 0 || ly < 0 
           					|| rx > remotewidth || ry > remoteheight || rx < 0 || ry < 0){
          				XMLout.generror(results, root,"terminalOutOfBounds","mapTerminal",parameters, command);
           			} else if (!airports.containsKey(airportName)){
           				XMLout.generror(results, root,"airportDoesNotExist","mapTerminal",parameters, command);
           			} else if  (!(airports.get(airportName).getRx() == rx && airports.get(airportName).getRy() == ry)){
           				XMLout.generror(results, root,"airportNotInSameMetropole","mapTerminal",parameters, command);
           			} else if (!nameFindCity.containsKey(termCity)){
           				XMLout.generror(results, root,"connectingCityDoesNotExist","mapTerminal",parameters, command);
           			} else if (!(rx == nameFindCity.get(termCity).getRx() && ry == nameFindCity.get(termCity).getRy() )){
           				XMLout.generror(results, root,"connectingCityNotInSameMetropole","mapTerminal",parameters, command);
          
           			} else if  (!cityMap.containsKey(termCity) ){
           				XMLout.generror(results, root,"connectingCityNotMapped","mapTerminal",parameters, command);
           			} else if (PMtryR(new Road (newterm, nameFindCity.get(termCity)), localMap) == false){
           				XMLout.generror(results, root,"terminalViolatesPMRules","mapTerminal",parameters, command);
           			} else {
           				newterm.setType("terminal");
           				Road newroad = new Road (newterm, nameFindCity.get(termCity)); 
           				
           				boolean interset = false;
           				for (Road r: roads){
           					if (r.getEc().getRx() == newroad.getEc().getRx() && r.getEc().getRy() == newroad.getEc().getRy()){
           					if (r.getEc().getName().equals (newroad.getSc().getName())){
           						double rxx = r.getSc().getLx();
           						double rxy = r.getSc().getLy();
           						double nx = newroad.getEc().getLx();
           						double ny = newroad.getEc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           						
           					} else if (r.getEc().getName().equals(newroad.getEc().getName())){
           						double rxx = r.getSc().getLx();
           						double rxy = r.getSc().getLy();
           						double nx = newroad.getSc().getLx();
           						double ny = newroad.getSc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           					
           					}else if (r.getSc().getName().equals (newroad.getSc().getName())){
           						double rxx = r.getEc().getLx();
           						double rxy = r.getEc().getLy();
           						double nx = newroad.getEc().getLx();
           						double ny = newroad.getEc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           					} else  if ( r.getSc().getName().equals(newroad.getEc().getName())){
           						double rxx = r.getEc().getLx();
           						double rxy = r.getEc().getLy();
           						double nx = newroad.getSc().getLx();
           						double ny = newroad.getSc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           						
           					}else if (r.getLine().intersectsLine(newroad.getLine()) ){
           						interset = true;
           					}
           					}
           				
           				}           				
           				if (interset){
           					XMLout.generror(results, root,"roadIntersectsAnotherRoad","mapTerminal",parameters, command);
           				} else {
           				
           					
           					try{
 
           					  localMap.insert(newroad);
           					  remote.put(rPoint, localMap);
           					}
           					catch (PMEcpt e1){
           					}
           				
           			
           				terms.put(termName, newterm);
           				cityMap.put(termName, newterm);
           				cityMap.put(termName, nameFindCity.get(termCity));
        
         
           			    
           			 if (roadmap.containsKey(termName)){
            				roadmap.get(termName).add(termCity);		
            			} else {
            				ArrayList<String> k = new ArrayList<String> ();
            				k.add(termCity);
            				roadmap.put(termName, k);
            			}
            			
            			if (roadmap.containsKey(termCity)){
            				roadmap.get(termCity).add(termName);	
            			} else {
            				ArrayList<String> k = new ArrayList<String> ();
            				k.add(termName);
            				roadmap.put(termCity, k);
            			}
           			    
           			    
           			    
           			    Element success = results.createElement("success");
						Element output = results.createElement("output");
						root.appendChild(success);
						success.appendChild(command);
						success.appendChild(parameters);
					
						success.appendChild(output);
           			    
           			}
           			
           			}
           			
          		}
           		
           		else if (commandIn.getNodeName().equals("mapRoad") ){
           			String id = ""; 
					
					try {
						id = commandAttr.getNamedItem("id").getNodeValue();
					} catch (NullPointerException e1) {
						// TODO Auto-generated catch block
						id = "";
					}
						
           			String scname = commandAttr.getNamedItem("start").getNodeValue();
           			String ecname = commandAttr.getNamedItem("end").getNodeValue();
           			Element parameters = results.createElement("parameters");
           			Element start = results.createElement("start");
					Element end = results.createElement("end");
					start.setAttribute("value", scname);
					end.setAttribute("value", ecname);
					parameters.appendChild(start);
					parameters.appendChild(end);
					Rectangle2D region = new Rectangle2D.Float(0, 0, localwidth, localheight);
					PMQuadtree localMap = new PMQuadtree(localwidth, localheight, pmOrder); 
					if (nameFindCity.containsKey(scname)){
						   City c1 = nameFindCity.get(scname);
						   Point2D.Float rPoint = new Point2D.Float(c1.getRx(), c1.getRy());
						   if (remote.containsKey(rPoint)){
							   localMap = remote.get(rPoint);
						   }
					}
					/*City c1 = nameFindCity.get(scname);
					City c2 = nameFindCity.get(ecname);
					Boolean a1 = (nameFindCity.get(scname).getX()> width || (int) nameFindCity.get(scname).getY() > height
           					|| nameFindCity.get(ecname).getX()> width || (int) nameFindCity.get(ecname).getY() > height
           					|| nameFindCity.get(scname).getX() < 0 || (int) nameFindCity.get(scname).getY() <0
           					|| nameFindCity.get(ecname).getX() < 0 || (int) nameFindCity.get(ecname).getY() < 0);
					Boolean a2 = !(new Road (nameFindCity.get(scname), nameFindCity.get(ecname))).getLine().intersects(region);
					*/
           			
           			if (!nameFindCity.containsKey(scname)){
           				XMLout.errorMess(results, root,"startPointDoesNotExist","mapRoad",id, parameters);
           			} else if (!nameFindCity.containsKey(ecname)){
           				XMLout.errorMess(results, root,"endPointDoesNotExist","mapRoad",id, parameters);
           			} else if (scname.equals(ecname)){
           				XMLout.errorMess(results, root,"startEqualsEnd","mapRoad",id, parameters);
           			} else if (nameFindCity.get(scname).getRx() != nameFindCity.get(ecname).getRx()
           					  || nameFindCity.get(scname).getRy() != nameFindCity.get(ecname).getRy()){
           				XMLout.errorMess(results, root,"roadNotInOneMetropole","mapRoad",id, parameters);   				
           			} else if ((nameFindCity.get(scname).getX()> localwidth || (int) nameFindCity.get(scname).getY() > localheight
           					|| nameFindCity.get(ecname).getX()> localwidth || (int) nameFindCity.get(ecname).getY() > localheight
           					|| nameFindCity.get(scname).getX() < 0 || (int) nameFindCity.get(scname).getY() <0
           					|| nameFindCity.get(ecname).getX() < 0 || (int) nameFindCity.get(ecname).getY() < 0)
           					&& !(new Road (nameFindCity.get(scname), nameFindCity.get(ecname))).getLine().intersects(region)){
           				/*
       					
       					*(!Inclusive2DIntersectionVerifier.intersects((new Road (nameFindCity.get(scname), nameFindCity.get(ecname))).getLine(),
           					region))
       					*/
           				XMLout.errorMess(results, root,"roadOutOfBounds","mapRoad",id, parameters);
           				
           			} else if (roads.contains(new Road(nameFindCity.get(scname), nameFindCity.get(ecname)))){
           				XMLout.errorMess(results, root,"roadAlreadyMapped","mapRoad",id, parameters);	
           			} else {
           			
           				Road newroad = new Road (nameFindCity.get(scname), nameFindCity.get(ecname)); 
           			
           				boolean interset = false;
           				for (Road r: roads){
           					if (r.getEc().getRx() == newroad.getEc().getRx() && r.getEc().getRy() == newroad.getEc().getRy()){
           					if (r.getEc().getName().equals (newroad.getSc().getName())){
           						double rxx = r.getSc().getLx();
           						double rxy = r.getSc().getLy();
           						double nx = newroad.getEc().getLx();
           						double ny = newroad.getEc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           						
           					} else if (r.getEc().getName().equals(newroad.getEc().getName())){
           						double rxx = r.getSc().getLx();
           						double rxy = r.getSc().getLy();
           						double nx = newroad.getSc().getLx();
           						double ny = newroad.getSc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           					
           					}else if (r.getSc().getName().equals (newroad.getSc().getName())){
           						double rxx = r.getEc().getLx();
           						double rxy = r.getEc().getLy();
           						double nx = newroad.getEc().getLx();
           						double ny = newroad.getEc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           					} else  if ( r.getSc().getName().equals(newroad.getEc().getName())){
           						double rxx = r.getEc().getLx();
           						double rxy = r.getEc().getLy();
           						double nx = newroad.getSc().getLx();
           						double ny = newroad.getSc().getLy();
           						if (r.contains(nx,ny) || newroad.contains(rxx,rxy)){
           							interset = true;
           						}
           						
           					}else if (r.getLine().intersectsLine(newroad.getLine()) ){
           						interset = true;
           					}
           					}
           				
           				}
           				if (interset){
           					XMLout.errorMess(results, root,"roadIntersectsAnotherRoad","mapRoad",id, parameters);
           				} else {
           					
           					if (PMtryR(newroad,localMap) == false){
           						XMLout.errorMess(results, root,"roadViolatesPMRules","mapRoad",id, parameters);
           					} else {
           					
           					
           				
           				
           			City sc = newroad.getSc();
           			City ec = newroad.getEc();
           			if (!cityMap.containsKey(sc.getName()) && sc.getX() <= localwidth && sc.getX() >= 0 
           					&& sc.getY() <= localheight && sc.getY() >= 0){
           				cityMap.put(sc.getName(), sc);
           				mapped.add(sc.getName());
           				//spatialMap.insert(sc);
           			}
           			if (!cityMap.containsKey(ec.getName()) && ec.getX() <= localwidth && ec.getX() >= 0 
           					&& ec.getY() <= localheight && ec.getY() >= 0){
           				cityMap.put(ec.getName(), ec);
           				mapped.add(ec.getName());
           			//	spatialMap.insert(ec);
           			}
           			
           			roads.add(newroad);
           			try{
     			
     					  localMap.insert(newroad);
     					}
     					catch (PMEcpt e1){
     					}
           			City c1 = nameFindCity.get(scname);
					   Point2D.Float rPoint = new Point2D.Float(c1.getRx(), c1.getRy());
                    remote.put(rPoint, localMap);
                    if (onlycity.containsKey(rPoint)){
                    	ArrayList<City> citylist = onlycity.get(rPoint);
                    	citylist.add(nameFindCity.get(scname));
                    	citylist.add(nameFindCity.get(ecname));
                    	onlycity.put(rPoint, citylist);
                    } else {
                    	ArrayList<City> citylist = new ArrayList<City>();
                    	citylist.add(nameFindCity.get(scname));
                    	citylist.add(nameFindCity.get(ecname));
                    	onlycity.put(rPoint, citylist);
                    }
                    
           			if (sc.getX() <= localwidth && sc.getX() >= 0 
           					&& sc.getY() <= localheight && sc.getY() >= 0 && ec.getX() <= localwidth && ec.getX() >= 0 
           					&& ec.getY() <= localheight && ec.getY() >= 0){
           			
           			if (roadmap.containsKey(scname)){
           				roadmap.get(scname).add(ecname);	
           			} else {
           				ArrayList<String> k = new ArrayList<String> ();
           				k.add(ecname);
           				roadmap.put(scname, k);
           			}
           			
           			if (roadmap.containsKey(ecname)){
           				roadmap.get(ecname).add(scname);	
           			} else {
           				ArrayList<String> k = new ArrayList<String> ();
           				k.add(scname);
           				roadmap.put(ecname, k);
           			}
           			
           			}
           			
           			Element success = results.createElement("success");
					Element command = results.createElement("command");
					Element output = results.createElement("output");
					Element roadcreate = results.createElement("roadCreated");
					roadcreate.setAttribute("start", scname);
					roadcreate.setAttribute("end", ecname);
					
					
					command.setAttribute("name", "mapRoad");
					if (!id.equals("")){
						command.setAttribute("id", id);
					}
					
					
					root.appendChild(success);
					success.appendChild(command);
					success.appendChild(parameters);
					
					success.appendChild(output);
					output.appendChild(roadcreate);
           				}
           				}
           			}
           			
           		} else if (commandIn.getNodeName().equals("unmapRoad")) {
           			String startc = commandAttr.getNamedItem("start").getNodeValue();
           			String endc = commandAttr.getNamedItem("end").getNodeValue();
           			Element command = results.createElement("command");
           			command.setAttribute("name", "unmapRoad");
           			Element parameters = results.createElement("parameters");
           			Element pstart = results.createElement("start");
           			Element pend = results.createElement("end");
           			pstart.setAttribute("value", startc);
           			pend.setAttribute("value", endc);
  					String id = "";
  					try {
  						id = commandAttr.getNamedItem("id").getNodeValue();
  						command.setAttribute("id", id);
  					} catch (NullPointerException e1) {
  						// TODO Auto-generated catch block
  						
  					} 
           			if (terms.containsKey(startc) || !nameFindCity.containsKey(startc) ){
           				XMLout.errorMess(results, root,"startPointDoesNotExist","unmapRoad",id, parameters);
           			} else if (terms.containsKey(endc) || !nameFindCity.containsKey(endc) ){
           				XMLout.errorMess(results, root,"endPointDoesNotExist","unmapRoad",id, parameters);
           			} else if (startc.equals(endc)){
           				XMLout.errorMess(results, root,"startEqualsEnd","unmapRoad",id, parameters);
           			} else {
           				Road droad = new Road(nameFindCity.get(startc), nameFindCity.get(endc));
           				if (!roads.contains(droad)){
           					XMLout.errorMess(results, root,"roadNotMapped","unmapRoad",id, parameters);
           				} else {
           					Point2D.Float rPoint = new Point2D.Float(droad.getEc().getRx(), droad.getEc().getRy());
           					PMQuadtree localMap = remote.get(rPoint);
           					ArrayList<City> citylist = onlycity.get(rPoint);
           					localMap.deleteR(droad);
           					remote.put(rPoint, localMap);
           					cityMap.remove(startc);
           					cityMap.remove(endc);
           					mapped.remove(startc);
           					mapped.remove(endc);
           					roads.remove(droad);
           		
           					
           					
           					if (citylist.isEmpty()){
           						onlycity.remove(rPoint);
           					} else {
           						onlycity.put(rPoint, citylist);
           					}
           					
           					Element output = results.createElement("output");
           					Element rodete = results.createElement("roadDeleted");
           					rodete.setAttribute("start", startc);
           					rodete.setAttribute("end", endc);
           					Element success = results.createElement("success");

        					root.appendChild(success);
        					success.appendChild(command);
        					success.appendChild(parameters);
        					
        					success.appendChild(output);
        					output.appendChild(rodete);
           				}
           				
           				
           				
           			}
           			
           		
           		
           		}else if (commandIn.getNodeName().equals("unmapAirport")) {
           			String airportName = commandAttr.getNamedItem("name").getNodeValue();
           			Element pname = results.createElement("name");
           			
             	    pname.setAttribute("value", airportName);
             	   Element command = results.createElement("command");
  					command.setAttribute("name", "unmapAirport");
  					String id = "";
  					try {
  						id = commandAttr.getNamedItem("id").getNodeValue();
  						command.setAttribute("id", id);
  					} catch (NullPointerException e1) {
  						// TODO Auto-generated catch block
  						
  					} 
           			
           			if (airports.containsKey(airportName)){
           				XMLout.generror(results, root,"airportDoesNotExist","unmapAirport",pname, command);
           			} else if (!airports.containsKey(airportName)){
           				XMLout.generror(results, root,"cityNotMapped","mapCity",pname, command);
           			}  else {
           				
           				airports.remove(airportName);
         
           	
           				
           				
           				
           				
           				
           				Element success = results.createElement("success");
		
						Element parameters = results.createElement("parameters");
						Element name = results.createElement("name");
						Element output = results.createElement("output");
						
						name.setAttribute("value", airportName);
						root.appendChild(success);
						success.appendChild(command);
						success.appendChild(parameters);
						parameters.appendChild(name);
						success.appendChild(output);
           			}
           			
           			
           			
           		} else if (commandIn.getNodeName().equals("printPMQuadtree")) {
           			int rx = Integer.parseInt(commandAttr.getNamedItem("remoteX").getNodeValue());
   					int ry = Integer.parseInt(commandAttr.getNamedItem("remoteY").getNodeValue());
   					
   				 Element parameters = results.createElement("parameters");
		
					Element erx = results.createElement("remoteX");
					Element ery = results.createElement("remoteY");
					
					
					
					erx.setAttribute("value", String.valueOf((int) rx));
					ery.setAttribute("value", String.valueOf((int) ry));
					parameters.appendChild(erx);
					parameters.appendChild(ery);
					
					Point2D.Float rPoint = new Point2D.Float(rx, ry);
           			if (!remote.containsKey(rPoint)){
           				XMLout.generror(results, root, "mapIsEmpty", "printPMQuadtree");
           			} else {
           				PMQuadtree spatialMap = remote.get(rPoint);
           				Element success = results.createElement("success");
    					Element command = results.createElement("command");
    					command.setAttribute("name", "printPMQuadtree");
    					Element output = results.createElement("output");
    					Element quad = spatialMap.print(results);
    					String id = "";
       					try {
       						id = commandAttr.getNamedItem("id").getNodeValue();
       						command.setAttribute("id", id);
       						
       					} catch (NullPointerException e1) {
       						// TODO Auto-generated catch block
       					}
       					
  
    					root.appendChild(success);
    					success.appendChild(command);
    					success.appendChild(parameters);
    					success.appendChild(output);
    					output.appendChild(quad);
    					
						
           				
           				
           				
           				
           				
           				
           			}
           			
           			
           			
           		} else if (commandIn.getNodeName().equals("saveMap")) {
           			String filename = commandAttr.getNamedItem("name").getNodeValue();
           			
           		/*	spatialMap.canvasPrint(canvas);*/
           			Element command = results.createElement("command");
           			command.setAttribute("name", "saveMap");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			
           			
           			Element success = results.createElement("success");

					Element parameters = results.createElement("parameters");
					Element pname = results.createElement("name");
					
					Element output = results.createElement("output");

					
                    pname.setAttribute("value", filename);
					root.appendChild(success);
					success.appendChild(command);
					success.appendChild(parameters);
					parameters.appendChild(pname);
					success.appendChild(output);
					
					
		//			canvas.save(filename);
           			
           			
           			
           			
           			
           		} else if (commandIn.getNodeName().equals("rangeCities")) {
           			
           			Element command = results.createElement("command");
   					command.setAttribute("name", "rangeCities");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			
   					int cx = Integer.parseInt(commandAttr.getNamedItem("x").getNodeValue());
   					int cy = Integer.parseInt(commandAttr.getNamedItem("y").getNodeValue());
   					int cr = Integer.parseInt(commandAttr.getNamedItem("radius").getNodeValue());
   					
   					
   					 
   
   					
   							
   					
           			
   					TreeSet<City> list = new TreeSet<City>(cityComp());
   					
   					for (City c: cityMap.values()){
   						double dist = Point2D.distance(cx, cy, c.getX(), c.getY());
   						if (dist <= cr){
   							list.add(c);
   						}
   					}
   					
   			/*				list = spatialMap.rangeCity(cx,cy,cr, cityComp());*/
   					if (list.isEmpty()){
   						Element error = results.createElement("error");
   
   						Element parameters = results.createElement("parameters");
   						Element px = results.createElement("x");
   						Element py = results.createElement("y");
   						Element pr = results.createElement("radius");
   						px.setAttribute("value", String.valueOf((int) cx));
   						py.setAttribute("value", String.valueOf((int) cy));
   						pr.setAttribute("value", String.valueOf((int) cr));
   						parameters.appendChild(px);
   						parameters.appendChild(py);
   						parameters.appendChild(pr);
   						
   						try {
   	   						String saveMap = commandAttr.getNamedItem("saveMap").getNodeValue();
   	   						Element sm = results.createElement("saveMap");
   	   						sm.setAttribute("value", saveMap);
   	   						parameters.appendChild(sm);
   	   					} catch (NullPointerException e1) {
   	   						// TODO Auto-generated catch block
   	   						
   	   					} 
   						

   						
   						error.setAttribute("type", "noCitiesExistInRange");
   			

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
   						
   						
   						
   						
   					} else {
   						
           			
           			
           			
           			
           			
           			Element success = results.createElement("success");
	
					Element parameters = results.createElement("parameters");
					Element px = results.createElement("x");
					Element py = results.createElement("y");
					Element pr = results.createElement("radius");
					px.setAttribute("value", String.valueOf((int) cx));
					py.setAttribute("value", String.valueOf((int) cy));
					pr.setAttribute("value", String.valueOf((int) cr));
					
					
					
					
					
					Element output = results.createElement("output");
					
					Element citylist = results.createElement("cityList");
					
					
					
					for (City c: list){
						Element cityE = results.createElement("city");
						cityE.setAttribute("name", c.getName());
						cityE.setAttribute("x", String.valueOf((int) c.getX()));
						cityE.setAttribute("y", String.valueOf((int) c.getY()));
						cityE.setAttribute("radius", String.valueOf(c.getR()));
						cityE.setAttribute("color", c.getColor());

						citylist.appendChild(cityE);
						
						
					}
					

					root.appendChild(success);
					success.appendChild(command);
					success.appendChild(parameters);
					parameters.appendChild(px);
					parameters.appendChild(py);
					parameters.appendChild(pr);
					try {
   						String saveMap = commandAttr.getNamedItem("saveMap").getNodeValue();
   						Element sm = results.createElement("saveMap");
   						sm.setAttribute("value", saveMap);
   						parameters.appendChild(sm);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
					success.appendChild(output);
					output.appendChild(citylist);
           			
           			
           			
   					}
           			
           		}else if (commandIn.getNodeName().equals("rangeRoads")) {
           			
           			Element command = results.createElement("command");
   					command.setAttribute("name", "rangeRoads");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			
   					int cx = Integer.parseInt(commandAttr.getNamedItem("x").getNodeValue());
   					int cy = Integer.parseInt(commandAttr.getNamedItem("y").getNodeValue());
   					int cr = Integer.parseInt(commandAttr.getNamedItem("radius").getNodeValue());
   					
   					
   					 
   
   					
   							
   					TreeSet<Road> list = new TreeSet<Road>(roadComp());
           			
   					
   					for (Road r: roads){
   						double dist = r.getLine().ptSegDist(cx, cy);
   						
   						if (dist <= cr){
   						
   							list.add(r);
   	   						
   						}
   					}
   					
   			/*				list = spatialMap.rangeCity(cx,cy,cr, cityComp());*/
   					if (list.isEmpty()){
   						Element error = results.createElement("error");
   
   						Element parameters = results.createElement("parameters");
   						Element px = results.createElement("x");
   						Element py = results.createElement("y");
   						Element pr = results.createElement("radius");
   						px.setAttribute("value", String.valueOf((int) cx));
   						py.setAttribute("value", String.valueOf((int) cy));
   						pr.setAttribute("value", String.valueOf((int) cr));
   						parameters.appendChild(px);
   						parameters.appendChild(py);
   						parameters.appendChild(pr);
   						
   						try {
   	   						String saveMap = commandAttr.getNamedItem("saveMap").getNodeValue();
   	   						Element sm = results.createElement("saveMap");
   	   						sm.setAttribute("value", saveMap);
   	   						parameters.appendChild(sm);
   	   					} catch (NullPointerException e1) {
   	   						// TODO Auto-generated catch block
   	   						
   	   					} 
   						

   						
   						error.setAttribute("type", "noRoadsExistInRange");
   			

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
   						
   						
   						
   						
   					} else {
   						
           			
           			
           			
           			
           			
           			Element success = results.createElement("success");
	
					Element parameters = results.createElement("parameters");
					Element px = results.createElement("x");
					Element py = results.createElement("y");
					Element pr = results.createElement("radius");
					px.setAttribute("value", String.valueOf((int) cx));
					py.setAttribute("value", String.valueOf((int) cy));
					pr.setAttribute("value", String.valueOf((int) cr));
					
					
					
					
					
					Element output = results.createElement("output");
					
					Element citylist = results.createElement("roadList");
					
					
					
					for (Road r: list){
						Element roadE = results.createElement("road");
						roadE.setAttribute("end", r.getEc().getName());
						roadE.setAttribute("start", r.getSc().getName());
				

						citylist.appendChild(roadE);
						
						
					}
					

					root.appendChild(success);
					success.appendChild(command);
					success.appendChild(parameters);
					parameters.appendChild(px);
					parameters.appendChild(py);
					parameters.appendChild(pr);
					try {
   						String saveMap = commandAttr.getNamedItem("saveMap").getNodeValue();
   						Element sm = results.createElement("saveMap");
   						sm.setAttribute("value", saveMap);
   						parameters.appendChild(sm);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
					success.appendChild(output);
					output.appendChild(citylist);
           			
           			
           			
   					}
           			
           		} else if (commandIn.getNodeName().equals("globalRangeCities")) {
           			Element command = results.createElement("command");
   					command.setAttribute("name", "globalRangeCities");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
   					int rx = Integer.parseInt(commandAttr.getNamedItem("remoteX").getNodeValue());
   					int ry = Integer.parseInt(commandAttr.getNamedItem("remoteY").getNodeValue());
   					int radi = Integer.parseInt(commandAttr.getNamedItem("radius").getNodeValue());
   					
   					Element parameters = results.createElement("parameters");
						Element prx = results.createElement("remoteX");
						Element pry = results.createElement("remoteY");
						Element pra = results.createElement("radius");
						prx.setAttribute("value", String.valueOf((int) rx));
						pry.setAttribute("value", String.valueOf((int) ry));
						pra.setAttribute("value", String.valueOf((int) radi));
						parameters.appendChild(prx);
						parameters.appendChild(pry);
						parameters.appendChild(pra);
						
						TreeMap <String, City> returncity  = new TreeMap<String, City>(stringCompare());
						for (Point2D.Float rPoint: onlycity.keySet()){
							if (rPoint.distance(rx, ry) <= radi){
								ArrayList<City> citylist = onlycity.get(rPoint);
								for (City c1: citylist){
									returncity.put(c1.getName(), c1);
								}
							}
						}
						
           			if (returncity.isEmpty()){
           				Element error = results.createElement("error");
 
   						error.setAttribute("type", "noCitiesExistInRange");
  

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
           				
           				
           				
           				
           			} else {
           				
           				Element cityl = results.createElement("cityList");  
           				for (City c1: returncity.values()){
           				
           				    
           				Element cityE = results.createElement("city");
						cityE.setAttribute("name", c1.getName());
						cityE.setAttribute("localX", String.valueOf((int) c1.getX()));
						cityE.setAttribute("localY", String.valueOf((int) c1.getY()));
						cityE.setAttribute("remoteX", String.valueOf((int) c1.getRx()));
						cityE.setAttribute("remoteY", String.valueOf((int) c1.getRy()));
						cityE.setAttribute("radius", String.valueOf(c1.getR()));
						cityE.setAttribute("color", c1.getColor());
						cityl.appendChild(cityE);
           				}
               			Element success = results.createElement("success");
 
    					Element output = results.createElement("output");
    					
    					
    					

    					root.appendChild(success);
    					success.appendChild(command);
    					success.appendChild(parameters);
    					success.appendChild(output);
    					output.appendChild(cityl);
    					
               			
               			
               			
           				
           				
           				
           			}
           			
           			
           			
           			
           			
           		}
           		
           		
           		else if (commandIn.getNodeName().equals("nearestCity")) {
           			Element command = results.createElement("command");
   					command.setAttribute("name", "nearestCity");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			int cx = Integer.parseInt(commandAttr.getNamedItem("localX").getNodeValue());
   					int cy = Integer.parseInt(commandAttr.getNamedItem("localY").getNodeValue());
   					int rx = Integer.parseInt(commandAttr.getNamedItem("remoteX").getNodeValue());
   					int ry = Integer.parseInt(commandAttr.getNamedItem("remoteY").getNodeValue());
   					
   					Element parameters = results.createElement("parameters");
						Element px = results.createElement("localX");
						Element py = results.createElement("localY");
						Element prx = results.createElement("remoteX");
						Element pry = results.createElement("remoteY");
						

						px.setAttribute("value", String.valueOf((int) cx));
						py.setAttribute("value", String.valueOf((int) cy));
						prx.setAttribute("value", String.valueOf((int) rx));
						pry.setAttribute("value", String.valueOf((int) ry));
						parameters.appendChild(px);
						parameters.appendChild(py);
						parameters.appendChild(prx);
						parameters.appendChild(pry);
						
						double distance = -1.0;
           				City returncity = null;
           				Point2D.Float rPoint = new Point2D.Float(rx, ry);
           				
           				if (onlycity.containsKey(rPoint)){
           					ArrayList<City> citylist = onlycity.get(rPoint);
           				for (City c: citylist){
           					if (c.getType().equals("city")){
           					
           					double newdis = Math.sqrt((c.getX() - cx)*(c.getX() - cx) + (c.getY() - cy)*(c.getY() - cy));
           					if (newdis < distance || distance < 0){
           						returncity = c;
           						distance = newdis;
           					} else if (newdis ==  distance && c.getName().compareTo(returncity.getName()) >0){
           						returncity = c;
           					}
           					}
           				}
						
           				}
           			if (/*spatialMap.isEmpty() || */  returncity == null){
           				Element error = results.createElement("error");
 
   						error.setAttribute("type", "cityNotFound");
  

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
           				
           				
           				
           				
           			} else {
           				

           				
           				
       
           				Element cityE = results.createElement(returncity.getType());
						cityE.setAttribute("name", returncity.getName());
						cityE.setAttribute("localX", String.valueOf((int) returncity.getX()));
						cityE.setAttribute("localY", String.valueOf((int) returncity.getY()));
						cityE.setAttribute("remoteX", String.valueOf((int) returncity.getRx()));
						cityE.setAttribute("remoteY", String.valueOf((int) returncity.getRy()));
						cityE.setAttribute("radius", String.valueOf(returncity.getR()));
						cityE.setAttribute("color", returncity.getColor());
               			
               			Element success = results.createElement("success");
 
    					Element output = results.createElement("output");
    					
    					
    					

    					root.appendChild(success);
    					success.appendChild(command);
    					success.appendChild(parameters);
    					success.appendChild(output);
    					output.appendChild(cityE);
    					
               			
               			
               			
           				
           				
           				
           			}
           			
           			
           			
           			
           			
           		} else if (commandIn.getNodeName().equals("nearestIsolatedCity")) {
           			Element command = results.createElement("command");
   					command.setAttribute("name", "nearestIsolatedCity");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			
           			int cx = Integer.parseInt(commandAttr.getNamedItem("x").getNodeValue());
   					int cy = Integer.parseInt(commandAttr.getNamedItem("y").getNodeValue());
   					
   					Element parameters = results.createElement("parameters");
						Element px = results.createElement("x");
						Element py = results.createElement("y");

						px.setAttribute("value", String.valueOf((int) cx));
						py.setAttribute("value", String.valueOf((int) cy));
						parameters.appendChild(px);
						parameters.appendChild(py);
						
						double distance = -1.0;
           				City returncity = null;
           				for (City c: airports.values()){
           					if (c.getType().equals("isolatedCity")){
           					
           					double newdis = Math.sqrt((c.getX() - cx)*(c.getX() - cx) + (c.getY() - cy)*(c.getY() - cy));
           					if (newdis < distance || distance < 0){
           						returncity = c;
           						distance = newdis;
           					} else if (newdis ==  distance && c.getName().compareTo(returncity.getName()) >0){
           						returncity = c;
           					}
           					}
           				}
						
						
           			if (/*spatialMap.isEmpty() || */returncity == null){
           				Element error = results.createElement("error");
   			
   						error.setAttribute("type", "cityNotFound");
   	

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
           				
           				
           				
           				
           			} else {
           				

           				
           				
       
           				Element cityE = results.createElement(returncity.getType());
						cityE.setAttribute("name", returncity.getName());
						cityE.setAttribute("x", String.valueOf((int) returncity.getX()));
						cityE.setAttribute("y", String.valueOf((int) returncity.getY()));
						cityE.setAttribute("radius", String.valueOf(returncity.getR()));
						cityE.setAttribute("color", returncity.getColor());
               			
               			Element success = results.createElement("success");
    
    					Element output = results.createElement("output");
    					
    					
    					


    					root.appendChild(success);
    					success.appendChild(command);
    					success.appendChild(parameters);
    					success.appendChild(output);
    					output.appendChild(cityE);
    					
               			
               			
               			
           				
           				
           				
           			}
           			
           			
           			
           			
           			
           		} else if (commandIn.getNodeName().equals("nearestRoad")) {
           			Element command = results.createElement("command");
   					command.setAttribute("name", "nearestRoad");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			int cx = Integer.parseInt(commandAttr.getNamedItem("x").getNodeValue());
   					int cy = Integer.parseInt(commandAttr.getNamedItem("y").getNodeValue());
   					
   					Element parameters = results.createElement("parameters");
						Element px = results.createElement("x");
						Element py = results.createElement("y");

						px.setAttribute("value", String.valueOf((int) cx));
						py.setAttribute("value", String.valueOf((int) cy));
						parameters.appendChild(px);
						parameters.appendChild(py);
						
						double distance = -1.0;
           				Road returnroad = null;
           				for (Road r: roads){
           					
           					
           					double newdis = r.getLine().ptSegDist(cx, cy);
           					if (newdis < distance || distance < 0){
           						returnroad = r;
           						distance = newdis;
           					} else if (newdis ==  distance){
           						if (r.getSc().getName().compareTo(returnroad.getSc().getName()) > 0){
           						returnroad = r;
           						} else if (r.getSc().getName().compareTo(returnroad.getSc().getName()) == 0) {
           							if (r.getEc().getName().compareTo(returnroad.getEc().getName()) > 0){
           								returnroad = r;
           							}
           						}
           					}
           					
           				}
						
						
           			if (/*spatialMap.isEmpty() || */ returnroad == null){
           				Element error = results.createElement("error");
 
   						error.setAttribute("type", "roadNotFound");
  

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
           				
           				
           				
           				
           			} else {
           				

           				
           				
       
           				Element roadE = results.createElement("road");
						roadE.setAttribute("start", returnroad.getSc().getName());
						roadE.setAttribute("end", returnroad.getEc().getName());
		
               			
               			Element success = results.createElement("success");
 
    					Element output = results.createElement("output");
    					
    					
    					

    					root.appendChild(success);
    					success.appendChild(command);
    					success.appendChild(parameters);
    					success.appendChild(output);
    					output.appendChild(roadE);
    					
               			
               			
               			
           				
           				
           				
           			}
           			
           			
           			
           			
           			
           		} else if (commandIn.getNodeName().equals("nearestCityToRoad")) {
           			Element command = results.createElement("command");
   					command.setAttribute("name", "nearestCityToRoad");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
           			String sc = commandAttr.getNamedItem("start").getNodeValue();
   					String ec = commandAttr.getNamedItem("end").getNodeValue();
   					
   					Element parameters = results.createElement("parameters");
					Element px = results.createElement("start");
					Element py = results.createElement("end");

					px.setAttribute("value", sc);
					py.setAttribute("value", ec);
					parameters.appendChild(px);
					parameters.appendChild(py);
					
					if (!nameFindCity.containsKey(sc) || !nameFindCity.containsKey(ec)){
						Element error = results.createElement("error");
          				 
   						error.setAttribute("type", "roadIsNotMapped");
  

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
						
					} else {
					
   					Road newroad = new Road (nameFindCity.get(sc), nameFindCity.get(ec));
   					
   				
						
						
						double distance = -1.0;
           				City returncity = null;
           				for (City c: cityMap.values()){
           					if (!c.getName().equals(sc) && !c.getName().equals(ec)){
           					
           					double newdis = newroad.getLine().ptSegDist(c.getX(), c.getY());
           					if (newdis < distance || distance < 0){
           						returncity = c;
           						distance = newdis;
           					} else if (newdis ==  distance && c.getName().compareTo(returncity.getName()) >0){
           						returncity = c;
           					}
           					}
           				}
						
           				if (!roads.contains(newroad)){
           					Element error = results.createElement("error");
           				 
       						error.setAttribute("type", "roadIsNotMapped");
      

       						root.appendChild(error);
       						error.appendChild(command);
       						error.appendChild(parameters);
							
						}
           				else if (returncity == null){
           				
           					Element error = results.createElement("error");
              				 
       						error.setAttribute("type", "noOtherCitiesMapped");
      

       						root.appendChild(error);
       						error.appendChild(command);
       						error.appendChild(parameters);
           				
           				
           				
           			} else {
           				

           				
           				
       
           				Element cityE = results.createElement("city");
						cityE.setAttribute("name", returncity.getName());
						cityE.setAttribute("x", String.valueOf((int) returncity.getX()));
						cityE.setAttribute("y", String.valueOf((int) returncity.getY()));
						cityE.setAttribute("radius", String.valueOf(returncity.getR()));
						cityE.setAttribute("color", returncity.getColor());
               			
               			Element success = results.createElement("success");
 
    					Element output = results.createElement("output");
    					
    					
    					

    					root.appendChild(success);
    					success.appendChild(command);
    					success.appendChild(parameters);
    					success.appendChild(output);
    					output.appendChild(cityE);
    					
               			
               			
               			
           				
           				
           				
           			}
           			
					}
           			
           			
           			
           		}
      	else if (commandIn.getNodeName().equals("printAvlTree")) {
           			
           			if (avl.isEmpty()){
           					Element error = results.createElement("error");
							Element parameters = results.createElement("parameters");
							Element command = results.createElement("command");
							try {
	       						String id = commandAttr.getNamedItem("id").getNodeValue();
	       						command.setAttribute("id", id);
	       					} catch (NullPointerException e1) {
	       					
	       						
	       					} 

							error.setAttribute("type", "emptyTree");
							command.setAttribute("name", "printAvlTree");

							root.appendChild(error);
							error.appendChild(command);
							error.appendChild(parameters);
           				
           				
           				
           			}else {
           				
           			
           			
           			Element success = results.createElement("success");
					Element command = results.createElement("command");
					
					command.setAttribute("name", "printAvlTree");
					try {
   						String id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   					
   						
   					} 

					Element parameters = results.createElement("parameters");
					Element output = results.createElement("output");
					output.appendChild(avlg.createXml(output));
				
					/*Element rootnode = avlg.printAvl(results);*/
					
	
					root.appendChild(success);
					success.appendChild(command);
					success.appendChild(parameters);
					success.appendChild(output);
					
					/*avltree.appendChild(rootnode);*/
           			
           			
           			}
           			
           		} else if (commandIn.getNodeName().equals("mst")) { 
           			String sc = commandAttr.getNamedItem("start").getNodeValue();
           			Element parameters = results.createElement("parameters");
           			Element start = results.createElement("start");
           			start.setAttribute("value", sc);
           			parameters.appendChild(start);
           			Element command = results.createElement("command");
   					command.setAttribute("name", "mst");
   					String id = "";
   					try {
   						id = commandAttr.getNamedItem("id").getNodeValue();
   						command.setAttribute("id", id);
   					} catch (NullPointerException e1) {
   						// TODO Auto-generated catch block
   						
   					} 
   			       if (!nameFindCity.containsKey(sc)){
   						Element error = results.createElement("error");
   						error.setAttribute("type", "cityDoesNotExist");
   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
   					
   					} else if (!cityMap.containsKey(sc)){
   						Element error = results.createElement("error");
   						error.setAttribute("type", "cityNotMapped");
   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
   						
   						
   						
           		}else {
   						Dijstra d1 = new Dijstra(roadmap, sc, cityMap);
   	   					Element path = d1.print(results);
   					 if (path != null){
   						Element success = results.createElement("success");
   						Element output = results.createElement("output");
   						root.appendChild(success);
   						success.appendChild(command);
   						success.appendChild(parameters);
   						success.appendChild(output);
   						output.appendChild(path);
   						
  
   						
   					} else {
   						
   						Element error = results.createElement("error");
          				 
   						error.setAttribute("type", "noPathExists");
  

   						root.appendChild(error);
   						error.appendChild(command);
   						error.appendChild(parameters);
   						
   					}
           		}
           			
           			
           		}
                   
                   
                
   
        		}
        		
        	}
        } catch (SAXException | IOException | ParserConfigurationException e) {
        	try {
				results = XmlUtility.getDocumentBuilder().newDocument();
				Element fatalError = results.createElement("fatalError");
				results.appendChild(fatalError);
			} catch (ParserConfigurationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        
        	
		} finally {
            try {
				XmlUtility.print(results);
			} catch (TransformerException e) {
				e.printStackTrace();
			}
        }
    }
}
