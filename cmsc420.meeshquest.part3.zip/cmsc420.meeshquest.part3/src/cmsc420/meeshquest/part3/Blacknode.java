package cmsc420.meeshquest.part3;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import cmsc420.drawing.CanvasPlus;

public class Blacknode extends PRNode {
	private City city = new City();
	private ArrayList<Road> roads = new ArrayList<Road>();
	private int card = 0;
		
	public Blacknode (City city, double x1, double x2, double y1, double y2){
	   this.city = city;
	   super.setX1(x1);
		super.setY1(y1);
		super.setX2(x2);
		super.setY2(y2);
		card ++;
	}
	
	public Blacknode(Road r, double x1, double x2, double y1, double y2) {
		roads.add(r);
		super.setX1(x1);
		super.setY1(y1);
		super.setX2(x2);
		super.setY2(y2);
		card ++;
	}
	
	public City getCity(){
		return city;
	}
	
	@Override
	public PRNode insert(City c) {
		PRNode grey = new greyNode(this.getX1(), this.getX2(), this.getY1(), this.getY2());
		grey = grey.insert(this.city);
		grey = grey.insert(c);
		for (Road r: roads){
			grey = grey.insertR(r);
		}
		return grey;
	}

	@Override
	public PRNode delete(City city) {
		// TODO Auto-generated method stub
		return new WhiteNode(this.getX1(), this.getX2(), this.getY1(), this.getY2());
	}

	@Override
	public void print(Document results, PRNode t, Element parent) {
		Element blacknode = results.createElement("black");
		blacknode.setAttribute("cardinality", Integer.toString(card));
		if (!this.city.getName().equals("not")){
			Element ecity = results.createElement("city");
			ecity.setAttribute("color", this.city.getColor());
			ecity.setAttribute("name", this.city.getName());
			ecity.setAttribute("radius", String.valueOf(this.city.getR()));
			ecity.setAttribute("x", Integer.toString( (int)city.getX()));
			ecity.setAttribute("y", Integer.toString( (int)city.getY()));
			blacknode.appendChild(ecity);
		}
		
		for (int i = roads.size() -1; i >= 0; i--){
			Road r = roads.get(i);
			Element eroad = results.createElement("road");
			eroad.setAttribute("start", r.getSc().getName());
			eroad.setAttribute("end", r.getEc().getName());
			blacknode.appendChild(eroad);
		}
		
		
		parent.appendChild(blacknode);
		
	}

	@Override
	public void canvansPrint(CanvasPlus c) {
		c.addPoint(this.city.getName(), this.city.getX(), this.city.getY(), Color.BLACK);
		
	}

	@Override
	public TreeSet<City> rangeCities(double x, double y, double r, Comparator<City> cityComp) {
		TreeSet<City> list = new TreeSet<City>(cityComp);
		double xd = (city.getX() - x);
		double yd = (city.getX() - y);
		double distance = (city.getX() - x)*(city.getX() - x) + (city.getY() - y)*(city.getX() - y);
		  if (Math.pow(city.getX() - x, 2) + Math.pow(city.getY() - y, 2) <= Math.pow(r, 2)){
			  list.add(city);
		  }
		  return list;
	}
	
	
	public void deletechange(double x1, double x2, double y1, double y2){
		 super.setX1(x1);
			super.setY1(y1);
			super.setX2(x2);
			super.setY2(y2);
	}

	
	
	@Override
	public PRNode insertR(Road r) {
		if (cross (r)){
			roads.add(r);
			card ++;
			
		} 
		return this;
	}

	/*
	public TreeSet<City> rangeCities(double x, double y, double r,Comparator<City> cityComp) {
	  TreeSet<City> list = new TreeSet<City>(cityComp);
	  if (Math.pow(city.getX() - x, 2) + Math.pow(city.getY() - y, 2) <= Math.pow(r, 2)){
		  list.add(city);
	  }
	  return list;
	}
	*/

}
