package cmsc420.meeshquest.part3;

public class Term extends City {
	protected String airportName, termName, termCity;
	protected int lx, ly, rx, ry;
	protected String type = "Terminal";
	
	public Term(String an, String tn, String tc, int lx, int ly, int rx, int ry){
		super.x = lx;
		super.y = ly;
		this.airportName = an;
		this.termName = tn;
		this.termCity = tc;
		this.lx = lx;
		this.ly = ly;
		this.rx = rx;
		this.ry = ry;
	}
	
	public String getType(){
    	return this.type;
    }
    
    public void setType(String type){
    	this.type = type;
    }
	
	
	public String getName() {
		return this.termName;
	}
	
	public String getAn(){
		return this.airportName;
	}
	public String getTn(){
		return this.termName;
	}
	
	public String getCn(){
		return this.termCity;
	}
	
	public int getLx(){
		return this.lx;
	}
	
	public int getLy(){
		return this.ly;
	}
	
	public int getRx(){
		return this.rx;
	}
	
	public int getRy(){
		return this.ry;
	}
}
