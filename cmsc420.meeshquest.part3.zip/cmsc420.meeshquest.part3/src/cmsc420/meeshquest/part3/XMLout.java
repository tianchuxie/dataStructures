package cmsc420.meeshquest.part3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.TreeSet;
import java.awt.Color;
import java.awt.geom.Point2D;


import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import cmsc420.xml.XmlUtility;
import cmsc420.drawing.CanvasPlus;
import cmsc420.meeshquest.part3.City;


public class XMLout {
	public static void outerror(Document results, City cityToInsert, Element root, String errortype){
		
		Element error = results.createElement("error");
		Element command = results.createElement("command");
		Element parameters = results.createElement("parameters");
		Element name = results.createElement("name");
		Element x = results.createElement("x");
		Element y = results.createElement("y");
		Element radius = results.createElement("radius");
		Element color = results.createElement("color");
		
		
		error.setAttribute("type", errortype);
		command.setAttribute("name", "createCity");
		name.setAttribute("value", cityToInsert.getName());
		x.setAttribute("value", String.valueOf((int) cityToInsert.getX()));
		y.setAttribute("value", String.valueOf((int) cityToInsert.getY()));
		radius.setAttribute("value", String.valueOf(cityToInsert.getR()));
		color.setAttribute("value", String.valueOf(cityToInsert.getColor()));

		root.appendChild(error);
		error.appendChild(command);
		error.appendChild(parameters);
		parameters.appendChild(name);
		parameters.appendChild(x);
		parameters.appendChild(y);
		parameters.appendChild(radius);
		parameters.appendChild(color);

		
	}
	
	public static void generror(Document results, Element root, String errortype, String commandtype){
		Element error = results.createElement("error");
		Element command = results.createElement("command");
		Element parameters = results.createElement("parameters");

		
		error.setAttribute("type", errortype);
		command.setAttribute("name", commandtype);

		root.appendChild(error);
		error.appendChild(command);
		error.appendChild(parameters);

		
	}
	
	public static void outsucces(Document results, City cityToInsert, Element root,String id, Element parameters){

		Element success = results.createElement("success");
		Element command = results.createElement("command");

		Element output = results.createElement("output");
		if (id != ""){
        command.setAttribute("id",id);}
		command.setAttribute("name", "createCity");
		
		root.appendChild(success);
		success.appendChild(command);
		success.appendChild(parameters);
		success.appendChild(output);
		
	}

	public static void generror(Document results, Element root, String errortype, String commandtype, Element parameters, Element command) {
		Element error = results.createElement("error");
		error.setAttribute("type", errortype);
		root.appendChild(error);
		error.appendChild(command);
		error.appendChild(parameters);
		
	}

	public static void errorMess(Document results, Element root, String string, String string2, String id, Element parameters) {
		Element error = results.createElement("error");
		Element command = results.createElement("command");

		
		error.setAttribute("type", string);
		command.setAttribute("name", string2);
        if (!id.equals("")){
        	command.setAttribute("id", id);
        }
		root.appendChild(error);
		error.appendChild(command);
		error.appendChild(parameters);
		
	}
	
	

}
