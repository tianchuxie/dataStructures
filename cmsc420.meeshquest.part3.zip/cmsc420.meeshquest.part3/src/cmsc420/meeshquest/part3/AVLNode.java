package cmsc420.meeshquest.part3;

@SuppressWarnings("hiding")
class AVLNode
{    
    AVLNode left, right;
    String data;
    int height;

    /* Constructor */
    public AVLNode()
    {
        left = null;
        right = null;
        data = null;
        height = 0;
    }
    /* Constructor */
    public AVLNode(String n)
    {
        left = null;
        right = null;
        data = n;
        height = 0;
    }     
}
