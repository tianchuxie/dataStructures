package cmsc420.meeshquest.part3;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import cmsc420.drawing.CanvasPlus;

public abstract class PRNode {
	
	private double x1,  y1, x2, y2 ;
	
	public abstract PRNode insert(City city);
	
	public abstract PRNode delete(City city);
	
	public abstract void print(Document results, PRNode t, Element parent);
	
	public abstract void canvansPrint(CanvasPlus c);
	
	
	public abstract TreeSet<City> rangeCities(double x, double y, double r, Comparator<City> cityComp);
	
	public boolean cross(Road r){
		double sx = r.getSc().getX(); 
		double sy = r.getSc().getY();
		double ex = r.getEc().getX();
		double ey = r.getEc().getY();
		double slope = (ey - sy) / (ex - sx);
		double ce = ey - slope * ex;
		double yslope = (ex - sx) / (ey - sy);
		double yce = ex - yslope * ey;
		if (ex < sx) {
			double k = sx; sx = ex; ex = k;
		}
		if (ey < sy){
			double k = ey; ey = sy; sy = k;
		}
		if (this.x1 <= sx && sx <= this.x2 && this.y1 <= sy && sy <= this.y2){
			return true;
		}
		double kx1 = slope * this.x1 + ce;
		if (kx1 <= y2 && kx1 >= y1 && sy <= kx1 && kx1 <= ey){
			return true;
		}
		double kx2 = slope * this.x2 + ce;
		if (kx2 <= y2 && kx2 >= y1 && sy <= kx2 && kx2 <= ey){
			return true;
		}
		
		
		double ky1 = yslope *this.y1 + yce;
		if (ky1 >= x1 && ky1 <= x2 && sx <= ky1 && ky1 <= ex){
			return true;
		}
		
		double ky2 = yslope *this.y2 + yce;
		if (ky2 >= x1 && ky2 <= x2 && sx <= ky2 && ky2 <= ex){
			return true;
		}
		return false;
	}
	
	public boolean isOverLap(double x, double y, double r){
		if (y - r >  this.y2){
			return false;
		}
		
		if (y + r <=  this.y1){
			return false;
		}
		
		if (x - r >=  this.x2){
			return false;
		}
		
		if (x + r < this.x1){
			return false;
		}
		
		return true;
	}
	

	public double getX1() {
		return x1;
	}

	public void setX1(double x1) {
		this.x1 = x1;
	}

	public double getY1() {
		return y1;
	}

	public void setY1(double y1) {
		this.y1 = y1;
	}

	public double getX2() {
		return x2;
	}

	public void setX2(double x2) {
		this.x2 = x2;
	}

	public double getY2() {
		return y2;
	}

	public void setY2(double y2) {
		this.y2 = y2;
	}
	
	public double getaX(){
		return (this.x1 + this.x2) /2;
	}
	
	public double getaY(){
		return (this.y1 + this.y2) /2;
	}

	public abstract PRNode insertR(Road r) ;

	

		
    
}
