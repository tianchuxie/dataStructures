package cmsc420.meeshquest.part3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.awt.Color;
import java.awt.geom.Point2D;


import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import cmsc420.xml.XmlUtility;
import cmsc420.drawing.CanvasPlus;
import cmsc420.meeshquest.part3.City;
public class PRTree {
	private double x1, y1, x2, y2;
	private PRNode root = null;
	public PRNode getRoot(){
		return root;
	}
	
	
	
	public PRTree (double x1, double y1, double x2, double y2){
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		root = new WhiteNode(x1, y1, x2, y2);
	}
	
	
	public void canvasPrint(CanvasPlus c){
		root.canvansPrint(c);
	}
	
	public void insert(Road r){
	     
	}
	
	public void  insert(City c){
		root =  root.insert(c);
	}


	public void deleteCity(City c){
		root = root.delete(c);
	}
	
	
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return root instanceof WhiteNode;
	}
	
	public Element print(Document results){
		Element rootnode = results.createElement("quadtree");
		rootnode.setAttribute("order", "3");
		root.print(results, root, rootnode);
		return rootnode;
	}
	
	
	public TreeSet<City> rangeCity(double x, double y, double r, Comparator<City> cityComp){
		return root.rangeCities(x, y, r, cityComp);
	}



	public void canvasaddCicle(int cx, int cy, int cr, CanvasPlus canvas) {
		canvas.addCircle(cx, cy, cr, Color.BLUE, false);
		
	}



	public void insertR(Road r) {
/*		City sc = r.getSc();
		City ec = r.getEc();
		root = root.insert(sc);
		root = root.insert(ec); */
		 root = root.insertR(r);
		
	}



	
	

}
