package cmsc420.meeshquest.part3;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.TreeSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.Comparator;
import java.util.HashMap;
import java.awt.geom.Point2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;

public class Dijstra {
	protected TreeMap<String, ArrayList<String>> adj = new TreeMap<String, ArrayList<String>>(stringCompareRight()) ;
    protected TreeMap<String, City> citys = new TreeMap<String, City> (); 
    protected String start, end;
	private TreeSet<String> unsettle;
	private TreeSet<String> settled;
	private int num_of_nodes;
	private HashMap<String, String> prev = new HashMap<String, String>();
	private HashMap<String, Double> distance = new HashMap<String, Double>();
	
	
	public class Vertex{
		protected String name;
		protected double distance;
	}
	
	
	public static Comparator<Vertex> vertexComp(){
		return new Comparator<Vertex>(){

			@Override
			public int compare(Vertex v1, Vertex v2) {
				
				if (! (v1.distance == v2.distance)){
					if (v1.distance > v2.distance){
						return 1;
					} else {
						return -1;
					}
					
				} else {
					if (v1.name.compareTo(v2.name) > 0){
						return 1;
					} else if ((v1.name.compareTo(v2.name) < 0)){
						return -1;
					} else {
						return 0;
					}
					
				}
			}

		};
	}
	
    public static Comparator<String> stringCompareRight(){
		return new Comparator<String>(){

			@Override
			public int compare(String city1, String city2) {

				if (city1.compareTo(city2) < 0){
					return -1;
				} else if (city1.compareTo(city2) > 0){
					return 1;
				} else {
					return 0;
				}
			}

		};
	}
	
    
   

 
	
	public Dijstra(TreeMap<String, ArrayList<String>> roads, String start, TreeMap<String, City> citys){
		this.start = start;
		this.citys = citys;
		this.adj = roads;
		this.num_of_nodes = roads.size();
		for (String v: roads.keySet()){
			this.distance.put(v, Double.MAX_VALUE);
		}
		
		unsettle = new TreeSet<String>();
		settled = new TreeSet<String>();
		
		String evalNode = "";
		unsettle.add(start);
		distance.put(start, 0.0);
		while (!unsettle.isEmpty() && !evalNode.equals(this.end)){
			evalNode = getNodeWithMinFromUnsettled();
			this.unsettle.remove(evalNode);
			this.settled.add(evalNode);
			evaluateNeighbours(evalNode);	
		}
	
		
		
		
		
		
	}
	
	


	private double findDist(String c1, String c2){
		City city1 = citys.get(c1);
		City city2 = citys.get(c2);
		return Point2D.distance(city1.getX(), city1.getY(), city2.getX(), city2.getY());
	}

	private void evaluateNeighbours(String evalNode) {
		double edgeDist = -1.0;
		double newDist = -1.0;
		
		for (String v: adj.get(evalNode)){
			if (!settled.contains(v)){
				edgeDist = findDist(evalNode, v);
				newDist = this.distance.get(evalNode) + edgeDist;
				if (newDist < this.distance.get(v)){
					this.distance.put(v, newDist);
					this.prev.put(v,evalNode);
				} else if (newDist == this.distance.get(v)){
					if (this.prev.get(v).compareTo(evalNode) > 0){
						this.prev.put(v, evalNode);
					}
				}
				unsettle.add(v);
			}
		}
				
	}

	private String getNodeWithMinFromUnsettled() {
		
		String node = this.unsettle.first();
		double min = this.distance.get(node);
		for (String v : this.distance.keySet()){
			if (unsettle.contains(v)){
				if (this.distance.get(v) > 0 && this.distance.get(v) <= min){
					min = distance.get(v);
					node = v;
				}
			}
		}
		
		return node;
	}
	

	public Element print(Document results){
		Element path = results.createElement("path");
		
		if (distance.get(this.end) == Double.MAX_VALUE){
			return null;
		}

		String travel = new String (this.end);
		Boolean visited = false;
		ArrayList<String> list = new ArrayList<String>();
		int count = 1;
		list.add(this.end);
		while (this.prev.containsKey(travel) && !this.prev.get(travel).equals(this.start)){
			travel = prev.get(travel);
			list.add(travel);
			count++;
		}
		
		
		if (!this.prev.containsKey(travel)){
			return null;
		} else {
			path.setAttribute("hops", String.valueOf(count));
			
			/*
			 *String.valueOf((double)(Math.round(distance.get(this.end)*1000)/1000.0)) */
			path.setAttribute("length", String.format("%.3f",distance.get(this.end)));
			String startpoint = this.start;
			String endpoint = this.start;
			for (int i = list.size() - 1; i >= 0; i--){
				startpoint = endpoint;
				endpoint = list.get(i);
				Element road = results.createElement("road");
				road.setAttribute("start", startpoint);
				road.setAttribute("end", endpoint);
				path.appendChild(road);
				if (i != 0){
					String nextpoint = list.get(i-1);
					Point2D.Float p1 = citys.get(startpoint).toPoint2D();
				    Point2D.Float p2 = citys.get(endpoint).toPoint2D();
				    Point2D.Float p3 = citys.get(nextpoint).toPoint2D();
				    
				    Arc2D.Float arc = new Arc2D.Float();
			
				    arc.setArcByTangent(p1,p2,p3,1);
				    double angle = arc.getAngleExtent(); 
				    if (angle >= 45.0 ){
				    	Element right = results.createElement("right");
				    	path.appendChild(right);
				    } else if (angle < -45.0){
				    	Element right = results.createElement("left");
				    	path.appendChild(right);
				    } else {
				    	Element right = results.createElement("straight");
				    	path.appendChild(right);
				    }
				}
			}
		}
		
		return path;
	}
	
	
	
    
	

}
