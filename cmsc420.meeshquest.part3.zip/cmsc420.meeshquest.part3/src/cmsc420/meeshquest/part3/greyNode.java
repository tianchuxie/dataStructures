package cmsc420.meeshquest.part3;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import cmsc420.drawing.CanvasPlus;

public class greyNode extends PRNode {
	private PRNode Q1, Q2, Q3, Q4;

	
	public greyNode(double x1, double x2, double y1, double y2){
		super.setX1(x1);
		super.setY1(y1);
		super.setX2(x2);
		super.setY2(y2);
		double xr = (x2 + x1) / 2.0;
		double yr = (y2 + y1) / 2.0;
		
		Q1 = new WhiteNode(xr, x2, yr, y2);
		Q2 = new WhiteNode(x1, xr, yr, y2);
		Q3 = new WhiteNode(x1, xr, y1, yr);
		Q4 = new WhiteNode(xr, x2, y1, yr);
	}
	@Override
	public PRNode insert(City city) {
	   double cx = city.getX();
	   double cy = city.getY();
	   double x1 = super.getX1();
	   double x2 = super.getX2();
	   double xr = (x2 + x1) / 2.0;
	   double y1 = super.getY1();
	   double y2 = super.getY2();
	   double yr = (y2 + y1) / 2.0;
	   
	   if ((cx >= xr) && (cx <= x2) && (cy >= yr) && (cy <= y2 )){
		   Q1 = this.Q1.insert(city);
	   } 
	   if ((cx >= x1) && (cx <= xr) && (cy >= yr) && (cy <= y2)){
		   Q2 = this.Q2.insert(city);
	   } 
	   if ((cx >= x1) && (cx <= xr) && (cy >= y1) && (cy <= yr)){
		   Q3 = this.Q3.insert(city);
	   } 
	   if ((cx >= xr) && (cx <= x2) && (cy >= y1) && (cy <= yr )){
		   Q4 = this.Q4.insert(city);
	   }
		   
	   
	   return this;
	}

	public PRNode getQ1() {
		return Q1;
	}

	public void setQ1(PRNode q1) {
		Q1 = q1;
	}

	public PRNode getQ2() {
		return Q2;
	}

	public void setQ2(PRNode q2) {
		Q2 = q2;
	}

	public PRNode getQ3() {
		return Q3;
	}

	public void setQ3(PRNode q3) {
		Q3 = q3;
	}

	public PRNode getQ4() {
		return Q4;
	}

	public void setQ4(PRNode q4) {
		Q4 = q4;
	}
	@Override
	public PRNode delete(City city) {
		// TODO Auto-generated method stub
		double cx = city.getX();
		   double cy = city.getY();
		   double x1 = super.getX1();
		   double x2 = super.getX2();
		   double xr = (x2 + x1) / 2.0;
		   double y1 = super.getY1();
		   double y2 = super.getY2();
		   double yr = (y2 + y1) / 2.0;
		   
		 if ((cx >= xr) && (cx < x2) && (cy >= yr) && (cy < y2 )){
			   Q1 = this.Q1.delete(city);
		   } else if ((cx >= x1) && (cx < xr) && (cy >= yr) && (cy < y2)){
			   Q2 = this.Q2.delete(city);
		   } else if ((cx >= x1) && (cx < xr) && (cy >= y1) && (cy < yr)){
			   Q3 = this.Q3.delete(city);
		   } else if ((cx >= xr) && (cx <= x2) && (cy >= y1) && (cy < yr )){
			   Q4 = this.Q4.delete(city);
		   }
		 
		   if (Q1 instanceof greyNode || Q2 instanceof greyNode || Q3 instanceof greyNode || Q4 instanceof greyNode){
			   return this;
		   }
		   
		   int count = 0;
		   
		   Blacknode temp = null;
		   if (Q1 instanceof Blacknode) {
			   count++;
			   temp = (Blacknode) Q1;
		   }
		   if (Q2 instanceof Blacknode) {
			   count++;
			   temp = (Blacknode) Q2;
		   }
		   if (Q3 instanceof Blacknode) {
			   count++;
			   temp = (Blacknode) Q3;
		   }
		   if (Q4 instanceof Blacknode) {
			   count++;
			   temp = (Blacknode) Q4;
		   }
		   
		   if (count == 1) {
			    temp.deletechange(super.getX1(), super.getX2(), super.getY1(), super.getY2());
			    return temp;
		   } else if (count == 0){
			   return new WhiteNode(super.getX1(), super.getX2(), super.getY1(), super.getY2());
		   }
		   
		   
		 
		 return this;
	}
	@Override
	public void print(Document results, PRNode t, Element parent) {
		Element graynode = results.createElement("gray");
		graynode.setAttribute("x", Integer.toString((int)(super.getX1() + super.getX2() )/2));
		graynode.setAttribute("y", Integer.toString((int)(super.getY1() + super.getY2() )/2));
		parent.appendChild(graynode);
		Q2.print (results, Q2, graynode);
		Q1.print (results, Q1, graynode);
		
		Q3.print (results, Q3, graynode);
		Q4.print (results, Q4, graynode);
	}
	@Override
	public void canvansPrint(CanvasPlus c) {

		double x1 = super.getX1();
	    double x2 = super.getX2();
	    double xr = (x2 + x1) / 2.0;
    	double y1 = super.getY1();
		double y2 = super.getY2();
		double yr = (y2 + y1) / 2.0;
		
		
		c.addLine(xr, y1, xr, y2, Color.BLACK);
		c.addLine(x1, yr, x2, yr, Color.BLACK);
		Q1.canvansPrint(c);
		Q2.canvansPrint(c);
		Q3.canvansPrint(c);
		Q4.canvansPrint(c);
		
	}
	@Override
	public TreeSet<City> rangeCities(double x, double y, double r, Comparator<City> cityComp) {
		TreeSet<City> list = new TreeSet<City>(cityComp);
		if (Q1.isOverLap(x, y, r)) list.addAll(Q1.rangeCities(x,y,r,cityComp));
		if (Q2.isOverLap(x, y, r)) list.addAll(Q2.rangeCities(x,y,r,cityComp));
		if (Q3.isOverLap(x, y, r)) list.addAll(Q3.rangeCities(x,y,r,cityComp));
		if (Q4.isOverLap(x, y, r)) list.addAll(Q4.rangeCities(x,y,r,cityComp));
		return list;
	}
	@Override
	public PRNode insertR(Road r) {
	
		if (Q1.cross (r)){
			Q1 = Q1.insertR(r);
		}
		if (Q2.cross (r)){
			Q2 = Q2.insertR(r);
		}
		if (Q3.cross (r)){
			Q3 = Q3.insertR(r);
		}
		if (Q4.cross (r)){
			Q4 = Q4.insertR(r);
		}
		// TODO Auto-generated method stub
		return this;
	}
	
	/*
	@Override
	public ArrayList<City> rangeCities(double x, double y, double r) {
		// TODO Auto-generated method stub
		ArrayList<City> list = new ArrayList<City>();
		if (Q1.isOverLap(x, y, r)) list.addAll(Q1.rangeCities(x,y,r));
		if (Q2.isOverLap(x, y, r)) list.addAll(Q1.rangeCities(x,y,r));
		if (Q3.isOverLap(x, y, r)) list.addAll(Q1.rangeCities(x,y,r));
		if (Q4.isOverLap(x, y, r)) list.addAll(Q1.rangeCities(x,y,r));
		return list;	
	}
	*/

}
