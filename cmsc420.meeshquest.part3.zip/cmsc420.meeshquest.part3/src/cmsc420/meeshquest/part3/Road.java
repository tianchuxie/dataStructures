package cmsc420.meeshquest.part3;

import java.awt.geom.Line2D;
import java.awt.geom.Line2D;
import java.awt.geom.Line2D.Float;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
public class Road extends Line2D {
	private City sc, ec;

	public Road(City city, City city2) {
		if (city.getName().compareTo(city2.getName()) >0){
			this.setSc(city2);
			this.setEc(city);
		} else {
		this.setSc(city);
		this.setEc(city2);
		}
	}
		
    public boolean contains(double xr, double yr){
    	double x1 = sc.getX();
    	double y1 = sc.getY();
    	double x2 = ec.getX();
    	double y2 = ec.getY();
    	double s = (y2 - y1) /(x2 - x1);
    	double e = y1 - x1* s;
    	if (y2 < y1){
			double k = y1;
			y1 = y2; 
			y2 = k;
		}
    	if (x2 < x1){
			double k = x1;
			x1 = x2; 
			x2 = k;
		}
    	
    	if (x1 == x2){
    		
    		return (y1 < yr && yr < y2 && x1== xr);
    	}
    	
    	if (y1 == y2){
    		
    		return (x1 < xr && xr < x2 && y1== yr);
    	}
    	
    	double check = s * xr + e;
    	if (check == yr){
    		boolean b = (x1 < xr && xr < x2 && y1 < yr && yr < y2);
    		return (x1 < xr && xr < x2 && y1 < yr && yr < y2);
    	} else {
    		return false;
    	}
    	
    	
    	
    }
	
	public Line2D getLine(){
		return new Line2D.Float(sc.toPoint2D(), ec.toPoint2D());
	}
	
	public Line2D getsmallerLine(){
		double x1 = sc.getX();
    	double y1 = sc.getY();
    	double x2 = ec.getX();
    	double y2 = ec.getY();
    	if (x1 < x2){
				x1 += 0.5;
				x2 -= 0.5;
			} else if (x1 > x2){
				x1 -= 0.5;
				x2 += 0.5;
			}
			
			if (y1 < y2){
				y1 += 0.5;
				y2 -= 0.5;
			} else if (y1 > y2) {
				y1 -= 0.5;
				y2 += 0.5;
			}
			
	    return new Line2D.Float((float)x1,(float)y1, (float)x2,(float)y2);
		
	}
	
	@Override
	public Rectangle2D getBounds2D() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getX1() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getY1() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Point2D getP1() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getX2() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getY2() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Point2D getP2() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setLine(double x1, double y1, double x2, double y2) {
		// TODO Auto-generated method stub
		
	}

	public City getSc() {
		return sc;
	}

	public void setSc(City sc) {
		this.sc = sc;
	}

	public City getEc() {
		return ec;
	}

	public void setEc(City ec) {
		this.ec = ec;
	}

}
