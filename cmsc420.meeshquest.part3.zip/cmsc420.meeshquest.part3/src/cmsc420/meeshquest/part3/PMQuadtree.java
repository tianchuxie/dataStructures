package cmsc420.meeshquest.part3;
import java.awt.Color;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Float;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class PMQuadtree {
	
	private PMNode root;
    private int pmorder;
    protected boolean viol;
    public class PMEcpt extends Exception{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		public PMEcpt(){
			
		}
    	
    }
    public class RoadComparator implements Comparator<Road> {
    	private Point2D.Float point;
    	private Double distanceToRoad1;
    	private Double distanceToRoad2;
    	
    	public RoadComparator(){
    		this.point = null;
    	}
    	
    	public RoadComparator(Point2D.Float point){
    		this.point = point;
    	}
    	
    	public int compare(Road road1, Road road2) {
    		if(point == null){
    			if(road1.getSc().getName().compareTo(road2.getSc().getName()) == 0){
    				return road1.getEc().getName().compareTo(road2.getEc().getName());
    			} else
    				return road1.getSc().getName().compareTo(road2.getSc().getName());
    		} else {
    			distanceToRoad1 = road1.getLine().ptSegDist(point);
    			distanceToRoad2 = road2.getLine().ptSegDist(point);
    			
    			if(distanceToRoad1 > distanceToRoad2){
    				return 1;
    			} else if (distanceToRoad1 < distanceToRoad2 ){
    				return -1;
    			} else {
    				return 0;
    			}
    		}
    	}
    }
    
    public static Comparator<Road> RoadCompare(){
		return new Comparator<Road>(){

			@Override
			public int compare(Road road1, Road road2) {

				if(road1.getSc().getName().compareTo(road2.getSc().getName()) == 0){
    				return road1.getEc().getName().compareTo(road2.getEc().getName());
    			} else
    				return road1.getSc().getName().compareTo(road2.getSc().getName());
    		
			}

		};
	}
    
	public boolean validator(TreeSet<Road> rds, ArrayList<City> cts){
		if (pmorder == 1){
			if (cts.size() > 1){
				return false;
			} else if (cts.size() == 1) {
				City ct = cts.get(0);
				for (Road r: rds){
					if (!r.getEc().getName().equals(ct.getName()) && !r.getSc().getName().equals(ct.getName())){
						return false;
					}
				}
				return true;
			} else {
				if (rds.size() >1){
					return false;
				} else {
					return true;
				}
			}
				
		} else if (pmorder == 3){
			if (cts.size() > 1){
				return false;
			} 
			return true;
			
		}
		
		return false;
	}
	
	public boolean inside (double x, double y, double w, double h, double x1, double y1){
		if ( x - w /2 <= x1 && x1 <= x + w /2 && y - h /2 <= y1 && y1 <= y + h/2){
			return true;
		} else {
			return false;
		}
	}
	
	public abstract class PMNode{
		protected double x;
		protected double y;
		protected double width;
		protected double height;
		PMNode (double x, double y, double width, double height) {
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
		}
		
		public boolean insider(City c){
			return inside(this.x, this.y, this.width, this.height, c.getX(), c.getY());
		}
		
		public abstract PMNode insertC(City c) throws PMEcpt;
		
		public abstract PMNode insertR(Road r) throws PMEcpt;
		
		public abstract PMNode delete(City c);
		public abstract PMNode delete(Road r);
		
		public boolean cross(Road r){
			double sx = r.getSc().getX(); 
			double sy = r.getSc().getY();
			double ex = r.getEc().getX();
			double ey = r.getEc().getY();
			double slope = (ey - sy) / (ex - sx);
			double ce = ey - slope * ex;
			double yslope = (ex - sx) / (ey - sy);
			double yce = ex - yslope * ey;
			double x1 = this.x - width;
			double x2 = this.x + width;
			double y1 = this.y - height;
			double y2 = this.y + height;
			if (ex < sx) {
				double k = sx; sx = ex; ex = k;
			}
			if (ey < sy){
				double k = ey; ey = sy; sy = k;
			}
			
			if (x1 <= sx && sx <= x2 && y1 <= sy && sy <= y2){
				return true;
			}
			double kx1 = slope * x1 + ce;
			if (kx1 <= y2 && kx1 >= y1 && sy <= kx1 && kx1 <= ey){
				return true;
			}
			double kx2 = slope * x2 + ce;
			if (kx2 <= y2 && kx2 >= y1 && sy <= kx2 && kx2 <= ey){
				return true;
			}
			
			
			double ky1 = yslope *y1 + yce;
			if (ky1 >= x1 && ky1 <= x2 && sx <= ky1 && ky1 <= ex){
				return true;
			}
			
			double ky2 = yslope * y2 + yce;
			if (ky2 >= x1 && ky2 <= x2 && sx <= ky2 && ky2 <= ex){
				return true;
			}
			return false;
		}

		public void print(Document results, PMNode root, Element rootnode) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	public class WhiteNode extends PMNode{

		WhiteNode(double x, double y, double width, double height) {
			super(x, y, width, height);
			// TODO Auto-generated constructor stub
		}
		

		@Override
		public PMNode insertC(City c) throws PMEcpt {
			// TODO Auto-generated method stub
			PMNode black = new BlackNode(this.x, this.y, this.width, this.height);
			black.insertC(c);
			return black;
		}

		@Override
		public PMNode insertR(Road r) throws PMEcpt {
			// TODO Auto-generated method stub
			PMNode black = new BlackNode(this.x, this.y, this.width, this.height);
			black = black.insertR(r);
			return black;
		}
		
		public void print(Document results, PMNode t, Element parent) {
			Element whitenode = results.createElement("white");
			parent.appendChild(whitenode);
			
		}


		@Override
		public PMNode delete(City c) {
			// TODO Auto-generated method stub
			return this;
		}


		@Override
		public PMNode delete(Road r) {
			// TODO Auto-generated method stub
			return this;
		}
		
	}
	
	
    public class BlackNode extends PMNode{
    	TreeSet<Road> roads = new TreeSet<Road>(new RoadComparator());
    	ArrayList<City> citys = new ArrayList<City>();

		BlackNode(double x, double y, double width, double height) {
			super(x, y, width, height);
			// TODO Auto-generated constructor stub
		}


		@Override
		public PMNode insertC(City c) throws PMEcpt {
			// TODO Auto-generated method stub
			if (insider(c) && !citys.contains(c)){
				
				citys.add(c);
				if (!validator(roads,citys)){
					if (width ==1 || height ==1){
						throw new PMEcpt();
					} 
					PMNode grey = new GreyNode(this.x, this.y, this.width, this.height);
					for (Road rd: roads){
						grey.insertR(rd);
					}
					
					for (City ct: citys){
						grey.insertC(ct);
					}
					
					return grey;
					
				} 
			}	
			
			return this;
		}

		@Override
		public PMNode insertR(Road r) throws PMEcpt {
			if (roads.contains(r)){
			
			} else {
				roads.add(r);
			}
			
			City sc = r.getSc();
			City ec = r.getEc();
			
			if (insider(sc) && !citys.contains(sc)){
				citys.add(sc);
			}
			
			if (insider(ec) && !citys.contains(ec)){
				citys.add(ec);
			}
				
			if (!validator(roads,citys)){
				if (width ==1 || height ==1){
					throw new PMEcpt();
				}
				PMNode grey = new GreyNode(this.x, this.y, this.width, this.height);
				for (Road rd: roads){
					grey.insertR(rd);
				}	
				for (City c: citys){
					grey.insertC(c);
				}
				return grey;
		
			} 
			
			return this;
		}
		
		
		public void print(Document results, PMNode t, Element parent) {
			Element blacknode = results.createElement("black");
			blacknode.setAttribute("cardinality", Integer.toString(roads.size() + citys.size()));
			for (City c: citys){
				String type = c.getType();
				Element ecity = results.createElement(c.getType());
				ecity.setAttribute("name", c.getName());
				ecity.setAttribute("localX", Integer.toString( (int)c.getX()));
				ecity.setAttribute("localY", Integer.toString( (int)c.getY()));
				ecity.setAttribute("remoteX", Integer.toString( (int)c.getRx()));
				ecity.setAttribute("remoteY", Integer.toString( (int)c.getRy()));
				if (type.equals("city")){
					ecity.setAttribute("color", c.getColor());
					ecity.setAttribute("radius", String.valueOf(c.getR()));
					
				} else if (type.equals("terminal")){
					ecity.setAttribute("cityName", ((Term) c).getCn());
					ecity.setAttribute("airportName", ((Term) c).getAn());
			
				}
			/*	ecity.setAttribute("color", c.getColor());
				ecity.setAttribute("name", c.getName());
				ecity.setAttribute("radius", String.valueOf(c.getR()));
				ecity.setAttribute("x", Integer.toString( (int)c.getX()));
				ecity.setAttribute("y", Integer.toString( (int)c.getY()));*/
				blacknode.appendChild(ecity);
			}
			
			for (Road r: roads.descendingSet()){
				Element eroad = results.createElement("road");
			    String ec = r.getEc().getName(); 
			    String sc = r.getSc().getName();
				eroad.setAttribute("start", sc);
				eroad.setAttribute("end", ec);
				
				blacknode.appendChild(eroad);
			}
			
			
			parent.appendChild(blacknode);
			
		}


		@Override
		public PMNode delete(City c) {
			if (insider(c)){
				citys.remove(c);
			}
			
			if (citys.size() == 0 && roads.size() == 0){
				return new WhiteNode(this.x, this.y, this.width, this.height);
			} else {
				return this;
			}
			
		}


		@Override
		public PMNode delete(Road r) {
			if (roads.contains(r)){
			roads.remove (r);
			}

			if (insider(r.getSc())){
				String namec = r.getSc().getName();
				boolean onlyone = true;
				for (Road r1: roads){
					if (r1.getEc().getName().equals(namec) || r1.getSc().getName().equals(namec)){
						onlyone = false;
					}
				}
				
				if (onlyone){
				citys.remove(r.getSc());
				}
			}
			
			if (insider(r.getEc())){
				String namec = r.getEc().getName();
				boolean onlyone = true;
				for (Road r1: roads){
					if (r1.getEc().getName().equals(namec) || r1.getSc().getName().equals(namec)){
						onlyone = false;
					}
				}
				
				if (onlyone){
				citys.remove(r.getEc());
				}
			}
			
			if (citys.size() == 0 && roads.size() == 0){
				return new WhiteNode(this.x, this.y, this.width, this.height);
			} else {
				return this;
			}
		}
		
	}
	
    public class GreyNode extends PMNode{
    	Rectangle2D[] regions;
    	PMNode[] quads;

		GreyNode(double x, double y, double width, double height) {
			super(x, y, width, height);
			regions = new Rectangle2D[4];
			quads = new PMNode[4];
			double hw = this.width /2;
			double hh = this.height/2; 
			quads[0] = new WhiteNode(x - hw/2, y + hh/2, hw, hh);
			quads[1] = new WhiteNode(x + hw/2, y + hh/2, hw, hh);
			quads[2] = new WhiteNode(x - hw/2, y - hh/2, hw, hh);
			quads[3] = new WhiteNode(x + hw/2, y - hh/2, hw, hh);
			regions[0] = new Rectangle2D.Double(x - hw, y, hw, hh);
			regions[1] = new Rectangle2D.Double(x , y , hw, hh);
			regions[2] = new Rectangle2D.Double(x - hw, y - hh, hw, hh);
			regions[3] = new Rectangle2D.Double(x, y - hh, hw, hh);
		}

		@Override
		public PMNode insertC(City c) throws PMEcpt {
			// TODO Auto-generated method stub
			for (int i = 0; i <= 3; i++){
				if (quads[i].insider(c)){
					quads[i] = quads[i].insertC(c);
				}
			}
			return this;
		}

		@Override
		public PMNode insertR(Road r) throws PMEcpt {
			// TODO Auto-generated method stub
			for (int i = 0; i <= 3; i++){
				if (r.getLine().intersects(regions[i])){
					quads[i] = quads[i].insertR(r);
				}
			}
			return this;
		}

		
		public void print(Document results, PMNode t, Element parent) {
			Element graynode = results.createElement("gray");
			graynode.setAttribute("x", Integer.toString((int)(this.x)));
			graynode.setAttribute("y", Integer.toString((int)(this.y)));
			parent.appendChild(graynode);
			for (int i = 0; i <= 3; i++){
				quads[i].print(results, quads[i], graynode);
			}

		}

		@Override
		public PMNode delete(City c) {
			boolean newwhite = true;
			boolean newblack = true;
			for (int i =0; i <= 3; i++){
					quads[i] = quads[i].delete(c);
					if (!(quads[i] instanceof WhiteNode)) newwhite = false;
					if (quads[i] instanceof GreyNode) newblack = false;
				
			}
			
			if (newwhite){
				return new WhiteNode(this.x, this.y, this.width, this.height);
			} else if (newblack ){
				BlackNode b = new BlackNode(this.x, this.y, this.width, this.height);
				for (int i =0; i <= 3; i++){
					if (quads[i] instanceof BlackNode){
						for (City c1: ((BlackNode)quads[i]).citys){
							try{
								b.insertC(c1);
							} catch(PMEcpt e1){
								
							}
							
						}
						
						
						for (Road r1: ((BlackNode)quads[i]).roads){
							try{
								b.insertR(r1);
							} catch(PMEcpt e1){
								
							}
							
						}
						
					}
					
					
					
				}
				
				return b;
			}
			return this;
		}

		@Override
		public PMNode delete(Road r) {
			boolean newwhite = true;
			boolean newblack = true;
			for (int i =0; i <= 3; i++){
				if (r.getLine().intersects(regions[i])){
					quads[i] = quads[i].delete(r);
					if (!(quads[i] instanceof WhiteNode)) newwhite = false;
					if (quads[i] instanceof GreyNode) newblack = false;
				}
			}
			
			if (newwhite){
				return new WhiteNode(this.x, this.y, this.width, this.height);
			} else if (newblack){
				PMNode b = new BlackNode(this.x, this.y, this.width, this.height);
				for (int i =0; i <= 3; i++){
					if (quads[i] instanceof BlackNode){
						for (City c: ((BlackNode)quads[i]).citys){
							try{
								b.insertC(c);
							} catch(PMEcpt e1){
								
							}
							
						}
						
						
						for (Road r1: ((BlackNode)quads[i]).roads){
							try{
								b.insertR(r1);
							} catch(PMEcpt e1){
								
							}
							
						}
						
					}
					
					
					
				}
				
				return b;
			}
			return this;
		}
	
		
	}

	
    
    public PMQuadtree (double width, double height, int order){
    	this.root = new WhiteNode( width / 2, height /2,  width, height);
    	this.pmorder = order;
    	this.viol = true;
    }
    
    public boolean getViol(){
    	return this.viol;
    }

	
    public void insertR(Road r) throws PMEcpt{
    	 root.insertR(r);
    }
	public void  insertC(City c) throws PMEcpt{
	   root.insertC(c);
	}
	
	public void insert(City c) throws PMEcpt{
		root = root.insertC(c);
	}
	
	public void insert(Road r) throws PMEcpt{
		root = root.insertR(r);
	}
	
	public void deleteR(Road r){
		root = root.delete(r);
	}
	public void deleteC(City c){
		root = root.delete(c);
	}
    
	public Element print(Document results){
		Element rootnode = results.createElement("quadtree");
		rootnode.setAttribute("order", Integer.toString(this.pmorder));
		root.print(results, root, rootnode);
		return rootnode;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return root instanceof WhiteNode;
	}
	
    
}
