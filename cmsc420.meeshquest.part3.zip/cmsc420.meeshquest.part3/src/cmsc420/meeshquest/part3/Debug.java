package cmsc420.meeshquest.part3;


import static org.junit.Assert.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import org.junit.Test;

/* Created by Stephen Xie */

public class Debug {

	static public void print(Object object) {
		System.err.println(object);
		System.err.println("--------------------");
	}

	final static private int TEST_START = 1;
	final static private int TEST_FINAL = 449;

	@Test
	public void all() {
		Debug.print("Testing Started");
		float fail = 0;
		float pass = 0;
		for (int i = Debug.TEST_START, l = Debug.TEST_FINAL; i <= l; ++i) {
			String name = "PSXT";
			String padding = (i < 10 ? "000" : i < 100 ? "00" : i < 1000 ? "0" : "") + i;
			String nameOut = name + "O" + padding + "K";
			try {
				System.setIn(new FileInputStream(name + "I" + padding));
				PrintStream printStream;
				printStream = new PrintStream(nameOut);
				System.setOut(printStream);
				String[] identification = new String[1];
				identification[0] = String.valueOf(i);
				cmsc420.meeshquest.part3.MeeshQuest.main(identification);
				printStream.close();
				if (compareFiles(nameOut, name + "O" + padding)) {
					++pass;
				
				} else {
					Debug.print("Failed -> " + padding);
					++fail;
				}
			} catch (FileNotFoundException e) {
				Debug.print("File Not Found"+ "::" + padding);
				// e.printStackTrace();
			} catch (IOException e) {
				Debug.print("IO Exception"+ "::" + padding);
				// e.printStackTrace();
			} catch (Exception e) {
				try {
					if (compareFiles(nameOut, name + "O" + padding)) {
						++pass;
					} else {
						Debug.print("Failed -> " + padding);
						Debug.print("Unhandled::" + e.getCause() + "::" + padding);
						e.printStackTrace();
						++fail;
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
		float success = (pass / (pass + fail));
		DecimalFormat precision = new DecimalFormat("#.000");
		Debug.print("Success Rate: " + precision.format(success) + ", " + "Standard Deviation: " + precision.format(Math.sqrt(success * (1 - success))));
		Debug.print("Testing Complete");

		if (fail > 0) {
			fail();
		}
	}

	private static boolean compareFiles(String file1, String file2) throws IOException {
		FileReader fR1 = new FileReader(file1);
		FileReader fR2 = new FileReader(file2);

		BufferedReader reader1 = new BufferedReader(fR1);
		BufferedReader reader2 = new BufferedReader(fR2);

		String line1 = null;
		String line2 = null;

		while (((line1 = reader1.readLine()) != null) && ((line2 = reader2.readLine()) != null)) {
			if (!line1.equals(line2)) {
				reader1.close();
				reader2.close();
				return false;
			}
		}
		if (reader1.readLine() == null && (line2 = reader2.readLine()) != null) {
			reader1.close();
			reader2.close();
			return false;
		}
		reader1.close();
		reader2.close();
		return true;
	}

}
